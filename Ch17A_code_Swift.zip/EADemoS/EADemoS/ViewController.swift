//
//  ViewController.swift
//  EADemoS
//
//  Created by Molly Maskrey on 1/18/16.
//  Copyright © 2016 Global Tek Labs. All rights reserved.
//

import UIKit
import ExternalAccessory



class ViewController: UITableViewController,  EAAccessoryDelegate {

@IBOutlet weak var infoLabel: UILabel!

// SAMPLE DATA FOR TABLE VIEW
//var sampleAccessoryArray:[String] = ["see no accessory", "hear no accessory", "speak no accesory"]
var sampleAccessoryArray: [String] = [""]

// External Accessory Stuff

var accessoryList:[EAAccessory]?            // our list of accessories, most likely there will only be one
let accessoryManager: EAAccessoryManager = EAAccessoryManager.sharedAccessoryManager()
var connectedAccessory: EAAccessory?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        print("EADEMO_S: registering for notifications")
        accessoryManager.registerForLocalNotifications()
        
        print("EADEMO_S: Adding notification observation")
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "connectedAccessory:", name: EAAccessoryDidConnectNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "disconnectedAccessory:", name: EAAccessoryDidDisconnectNotification, object: nil)
    }
    
    //
    // Not really used
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
        accessoryManager.unregisterForLocalNotifications()
    }


//
// This method gets notified via the accessory manager and notifcations when an accessory is connected
// via the dock connector or using Standard Bluetooth -- NOT BT low energy
//
func connectedAccessory(notification:NSNotification) {
    print("Accessory was found")
    let dict : [NSObject : AnyObject] = notification.userInfo!
    self.connectedAccessory = dict[EAAccessoryKey] as? EAAccessory
    sampleAccessoryArray[0] = connectedAccessory!.name
    let ip: [NSIndexPath] = [NSIndexPath(forRow:0, inSection: 0)]
    self.tableView.reloadRowsAtIndexPaths(ip, withRowAnimation: UITableViewRowAnimation.None)
    
}

//
// This method gets notified via the accessory manager and notifcations when an accessory is DISCONNECTED
// via the dock connector or using Standard Bluetooth -- NOT BT low energy
// All we do is erase the item in the table view cell...note that there is still a cell there, but it's blank
// so it might be that if you tap it, the blank cell, things may not work properly.

// ***NOTE*** There is an issue when you've gone into the detail view, come back to here and then
// disconnect the accessory. It doesn't seem to work properly. But that's probably not important
// to spend a lot of effort on as this is just for demo and baseline testing. 


func disconnectedAccessory(notification:NSNotification) {
    print("Accessory gone, possibly removed")
    sampleAccessoryArray[0] = ""
    let ip: [NSIndexPath] = [NSIndexPath(forRow:0, inSection: 0)]
    self.tableView.reloadRowsAtIndexPaths(ip, withRowAnimation: UITableViewRowAnimation.None)
}

//
//  This is how we pass the accessory to the detail view controller via the seque
//  as shown in the storyboards. Note that the name of the seque must be the same here
//  and as shown in the storyboard.
//
override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    if segue.identifier == "accessorySegue" {
        let accessoryScene = segue.destinationViewController as! DetailViewController
        accessoryScene.connectedAccessory  = self.connectedAccessory
    }
}

//
// Table View Data Source Methods
// Basic Xcode table view routines
//
override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//
    return 1
}
override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
    return self.sampleAccessoryArray.count
}

override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

    // NOTE: because this will be a small table view, I'm not worrying about
    //       reusing cells. It's just not needed here.
    //
    let cell = tableView.dequeueReusableCellWithIdentifier("accessorycell", forIndexPath: indexPath) as UITableViewCell    
    
    cell.textLabel?.text = self.sampleAccessoryArray[indexPath.row]
    return cell
}


}

