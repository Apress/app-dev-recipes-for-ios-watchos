//
//  DetailViewController.swift
//  EADemoS
//
//  Created by Molly Maskrey on 1/22/16.
//  Copyright © 2016 Global Tek Labs. All rights reserved.
//

import UIKit
import ExternalAccessory


// CHANGE THIS TO YOUR PROTOCOL STRING
// *NOTE* make sure to change the Supported External Accessory item in the "info.plist"
let myProtocolString = "com.RovingNetworks.btdemo"


//
// Because this class deals with the accessory, it needs to conform to the EAAccessory Delegate protocol
// And, since this is where we handle the actual data I/O across the channel, it must also conform
// to the NSStream Delegate protocol
//
class DetailViewController: UIViewController, EAAccessoryDelegate, NSStreamDelegate {

@IBOutlet weak var accessoryTitleLabel: UILabel!

@IBOutlet weak var statusLabel: UILabel!
@IBOutlet weak var outputDataLabel: UILabel!

//
// References to the accessory and the session
var connectedAccessory: EAAccessory?
var session: EASession?

// get access to the shared accessory manager
let accessoryManager: EAAccessoryManager = EAAccessoryManager.sharedAccessoryManager()


override func viewDidLoad() {
//
    super.viewDidLoad()
    self.accessoryTitleLabel.text = connectedAccessory!.name
    self.statusLabel.text = "accessory connected"
    self.connectedAccessory?.delegate = self
    
    accessoryManager.registerForLocalNotifications()
    NSNotificationCenter.defaultCenter().addObserver(self, selector: "disconnectedAccessory:", name: EAAccessoryDidDisconnectNotification, object: nil)
    self.openSession()
}


override func viewDidDisappear(animated: Bool) {
//
    print("DetailView Did Disappear")
    self.closeSession()
    NSNotificationCenter.defaultCenter().removeObserver(self)
    accessoryManager.unregisterForLocalNotifications()
}


// DATA MOVEMENT

//
// This is the event handler for any of the NSStream activity.
// In this demo, we're only concerned with reading data from the device.
// I've included the writeData call and method below, but they're
// just placeholders as the example BT device I'm using doesn't get
// written to.
func stream(aStream: NSStream, handleEvent eventCode: NSStreamEvent) {
    switch (eventCode) {
        case NSStreamEvent.None:
            print("NSStream Event None")
        case NSStreamEvent.OpenCompleted:
            print("NSStream Open Completed")
        case NSStreamEvent.HasBytesAvailable:
            print("NSStream Has Bytes Available")
            self.readData()
        case NSStreamEvent.HasSpaceAvailable:
            self.writeData()
        case NSStreamEvent.ErrorOccurred:
            print("NSStream Error Occured")
        case NSStreamEvent.EndEncountered:
            print("NSStream End Encountered")
        default:
            break;
    }
    
}


//
// KEY DATA I/O Method *** This is where the data from the accessory is brought in to this app
// via the NSStreams mostly managed by iOS and converted for display in a UILabel.
//

func    readData() {
    let maxReadLength = 20
    var inputDataArray = [UInt8](count: maxReadLength, repeatedValue: 0)

    var outputDataString : String = ""
//    print("array: \(inputDataArray)")
    while ((session?.inputStream?.hasBytesAvailable) == true) {
        let len = session?.inputStream?.read(&inputDataArray, maxLength: maxReadLength)
        if len > 0 {
        
//            print("\(len!) Read\n")
//            print("inputArray: \(inputDataArray)")


            // Conversion for display of some data
            // this is just for the demo app and only displays
            // some of the info from the BT board/card scanner
            // YOU'LL NEED TO CUSTOMIZE THIS AS APPROPRIATE FOR THE APPLICATION
            for value in inputDataArray {
                outputDataString += String(value, radix: 16)
            }
            
//            print("outputArray: \(outputDataString)")
            dispatch_async(dispatch_get_main_queue()) {
                self.statusLabel.text = "New Data Available:"
                self.outputDataLabel.text = outputDataString as String
                }
            
            }
    }
}

func    writeData() {
// This example does not write any data

}

func disconnectedAccessory(notification:NSNotification) {
    print("Accessory gone, possibly removed")
    self.statusLabel.text = "accessory disconnected"
    self.accessoryTitleLabel.text = "none"
    self.closeSession()
    NSNotificationCenter.defaultCenter().removeObserver(self)
    //
    //  Go back to table view controller
    //
    self.navigationController?.popToRootViewControllerAnimated(true)
}


// 
func openSession() {
    self.statusLabel.text = "opening session"
    session = EASession.init(accessory: self.connectedAccessory!, forProtocol: myProtocolString)
    if session != nil {
            self.statusLabel.text = "opened session to accessory"
        
            session?.inputStream?.delegate = self
            session?.inputStream?.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
            session?.inputStream?.open()
        
            session?.outputStream?.delegate = self
            session?.outputStream?.scheduleInRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
            session?.outputStream?.open()
        
        } else {
            self.statusLabel.text = "could not open session"
        }
}

func closeSession() {
    session?.inputStream?.close()
    session?.inputStream?.removeFromRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
    session?.inputStream?.delegate = nil
    
    session?.outputStream?.close()
    session?.outputStream?.removeFromRunLoop(NSRunLoop.currentRunLoop(), forMode: NSDefaultRunLoopMode)
    session?.outputStream?.delegate = nil

}

}
