//
//  ViewController.swift
//  DiscoBall
//
//  Created by Molly Maskrey on 12/17/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

import UIKit
import HomeKit

class ViewController: UIViewController, HMHomeManagerDelegate, HMAccessoryBrowserDelegate, HMAccessoryDelegate{


    // convenience constants
    let kmyHome = "MyHome"
    let kmainRoom = "MainRoom"
    // If using the simulator...
//    let kdiscoball = "DiscoBall"

    // If using the actual iHome SmartPlug
    // Note that the serial # will likely be different
    // on a device that you may use
    let kdiscoball = "iHome SmartPlug-1ABCFF"
    let kdiscoballDisplayName = "DiscoBall"

    // "Global" variables
    let manager = HMHomeManager()
    let browser = HMAccessoryBrowser()
    var accessories = [HMAccessory]()
    var services = [HMService]()
    var characteristics = [HMCharacteristic]()
    var discoBallPowerSwitch: HMCharacteristic?
    var isDiscoBallPowerOn : Bool = false

    
    // Some local "testing" variables
    var primaryHome : HMHome?
    var discoballAccessory : HMAccessory?
    var partyService : HMService?


    // OUTLET: Indicates if ball is on or off
    // if using the HKAccessory Similator this will
    // be the "Outlet in Use" characteristic
    @IBOutlet weak var deviceIndicator: UILabel!
    
    // OUTLET: Used to change the name on the top
    // UI button...the one that controls our disco ball
    // e.g. when the ball is on, we want the switch to
    // read "OFF" and vice versa
    @IBOutlet weak var switchStatus: UIButton!
    
    // ACTION: This method is called when the top button
    // is activated, used to turn the disco ball (accessory
    // outlet) ON or OFF
    @IBAction func activateDevice(sender: AnyObject) {
        self.activateDiscoBall()
    }
    
    // OUTLET: A simple, mostly diagnostic label we use
    // to display information about the located accessory.
    // It lets the user know the app has found our disco ball
    @IBOutlet weak var accessoryFound: UILabel!
    
    // OUTLET: A simple, mostly diagnostic label used
    // to indicate whether the accessory is connected or
    // not to the app
    @IBOutlet weak var accessoryStatus: UILabel!
    
    // ACTION: This method is called when the bottom button "ATTACH"
    // is pressed to make an attempt to connect the located accessory
    // to the app
    @IBAction func attachAccessory(sender: AnyObject) {
        self.addMyAccessory()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        manager.delegate = self
        print("Home Manager created and delegate set to self")
        
        browser.delegate = self
        print("Accessory Browser created and delegate set to self")
        
        // Go see if there are any accessories in the area
        browser.startSearchingForNewAccessories()
        
        // Only do it for a short period as it will drain the battery
        NSTimer.scheduledTimerWithTimeInterval(20.0, target: self, selector: "stopSearching", userInfo: nil, repeats: false)
        
        for home in self.manager.homes as [HMHome] {
            
            if home.name == kmyHome {
                print("Found MyHome")
                }
        }
        
        self.switchStatus.enabled = false
        self.switchStatus.titleLabel!.text = "Disabled"
        
        
        // call the addMyHome convenience method
        self.addMyHome()
        
    }
    
// Our Helper Methods
    func stopSearching() {
        print("stopSearching")
        browser.stopSearchingForNewAccessories()
    }
    
    //
    // Add our Home
    //
    func addMyHome() {
        manager.addHomeWithName(kmyHome, completionHandler: {(home, error) -> Void in
            print("Trying to add MyHome")
            if error == nil || error?.code == 32 { // error code 32 means the home is already in the database
            
                if error == nil {
                        print("MyHome added to database")
                        self.primaryHome = home
                    } else {
                        print("MyHome already in database")
                        }
                        
                    print("...either way, we can add a room to the home now")
                    //
                    // We've stored the house we added as our primary so we'll
                    // now add a room to it
                    //
                    if self.primaryHome != nil {
                        self.primaryHome!.addRoomWithName(self.kmainRoom, completionHandler: { (room, error) -> Void in
                            if error == nil || error?.code == 13  { // error code 13 means room already in home
                                if error == nil {
                                    print("Room added to Home")
                                    } else {
                                        print("Room ALREADY there")
                                        }
                                //
                                // But this might seem tricky, but we have to tell HomeKit to make this
                                // our primary home as well. Previously, we just essentially called it that
                                // but we have to do it in code so the database is "correct"
                                //
                                self.manager.updatePrimaryHome(self.primaryHome!, completionHandler: {(error) -> Void in
                                if error == nil {
                                        print("\(self.primaryHome!.name) now defined as the primary home")
                                    } else {
                                        print("ERROR: setting primary home: \(error)")
                                            }
                                    })

                                } else {
                                    print("ERROR: attempting to add room. \(error!.localizedDescription)")
                                }
                        
                            })
                        } else {
                                print("ERROR: For some reason our global primary home was not set")
                            }
                } else {
                    print("ERROR: attempting to add home: \(error)")
                }
                
            })
    }
    //
    //  End of setting up our simple one room home
    //  Note that we didn't do anything with accessories. We deal with those separately.
    //

    
    //
    // Stock method - no changes
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


func homeManagerDidUpdateHomes(manager: HMHomeManager) {

    print("Home Manager updated the homes database")
    for home in manager.homes as [HMHome] {
        if home.name == kmyHome {
            self.primaryHome = home
            print("Setting primaryHome to MyHome")
        }
     }
}

func homeManagerDidUpdatePrimaryHome(manager: HMHomeManager) {
    print("homeManagerDidUpdatePrimaryHome called")
}

func homeManager( manager: HMHomeManager,
               didAddHome home: HMHome) {
    print("Home Manager added a home")
}

func accessoryBrowser(browser: HMAccessoryBrowser,
  didFindNewAccessory accessory: HMAccessory) {

    print("Found a new accessory: \(accessory)")
    if accessory.name == kdiscoball {
        self.discoballAccessory = accessory
        self.accessoryFound.text = "Found \(self.kdiscoballDisplayName)"
        }
}


func listServices(accessory : HMAccessory) {
    for service in accessory.services {
        //
        // Go through any available services, find the Outlet service which
        // is just a HomeKit standard name that we've called our party service
        // and list all the characteristics for our "Party" service.
        //
        if service.serviceType == HMServiceTypeOutlet {
        self.services.append(service as HMService)
            print("found \(service.name) of type HMServiceTypeOutlet service for \(accessory.name)")
            self.partyService = service
            listCharacteristics(service)
        }
    }
}


func listCharacteristics(service: HMService) {
    for characteristic_item in service.characteristics {
        characteristics.append(characteristic_item as HMCharacteristic)
        print("value \(characteristic_item.value!) : \(characteristic_item.metadata!.manufacturerDescription!)")
        //
        // Notification of changes in characteristics are NOT automatically enabled, you have to do this yourself
        //
        if characteristic_item.properties.contains(HMCharacteristicPropertySupportsEventNotification) {
            characteristic_item .enableNotification(true, completionHandler: {(error) in
            if error != nil {
                print("Error while enabling notification for \(characteristic_item.metadata?.manufacturerDescription)")
            }
            else    {
                print("\(characteristic_item.metadata?.manufacturerDescription) Notification enabled")
                }
            })
        }
        //
        // let's also set our main power switch to a global for access by our UI button
        //
        if characteristic_item.metadata!.manufacturerDescription == "Power State" {
            print("Setting up our global discoBallPowerSwitch")
            self.discoBallPowerSwitch = characteristic_item
            
            //
            // Read the switch to determine if it is on or not and set the
            // power switch and button indicators appropriately, then
            // enable the power button
            //
        
            // First make sure the characteristic is readable
            if self.discoBallPowerSwitch!.properties.contains(HMCharacteristicPropertyReadable) {
                // Then prepare the value for reading
                self.discoBallPowerSwitch?.readValueWithCompletionHandler({(error) in
                    if (error) != nil {
                        print("Error occured reading the value of the Power Switch")
                        } else {
                            // Read the value
                            self.isDiscoBallPowerOn = self.discoBallPowerSwitch!.value as! Bool
                            print("Power On readback = \(self.discoBallPowerSwitch!.value as! Bool)")
                            print(self.isDiscoBallPowerOn)
                            }
                    })

                } else {
                    // Just as an example of the alternative
                    print("NO HMCharacteristicPropertyReadable PROPERTY")
                    }
                // enable the button
                self.switchStatus.enabled = true
            
                // Set the state of the label and power button depending on what we read back
                if self.isDiscoBallPowerOn  == true {
                    print("Turning indicator to ON")
                    self.deviceIndicator.text = "Disco Ball ON"
                    self.switchStatus.setTitle("Stop Party", forState: UIControlState.Normal)
                    self.switchStatus.titleLabel?.textAlignment = NSTextAlignment.Center
                } else {
                    print("Turning indicator to OFF")
                    self.deviceIndicator.text = "Disco Ball OFF"
                    self.switchStatus.setTitle("Start Party", forState: UIControlState.Normal)
                    self.switchStatus.titleLabel?.textAlignment = NSTextAlignment.Center
                    }
            }
    }
}

func accessoryBrowser(browser: HMAccessoryBrowser,
         didRemoveNewAccessory accessory: HMAccessory) {
        print("didRemoveNewAccessory: \(accessory.name)")
}


// ACCESSORY DELEGATE METHODS
    func accessory(accessory: HMAccessory, service: HMService, didUpdateValueForCharacteristic characteristic: HMCharacteristic) {
        print("\(accessory.name):  \(characteristic.metadata!.manufacturerDescription!) has changed to \(characteristic.value!)")
        if accessory.name == kdiscoball && characteristic.metadata!.manufacturerDescription == "Power State" {
            //
            // NOTE: in Apple's documentation, this value is shown in the list as a string, but
            //       in the details as a Bool. It works as a Bool as you see here...
            //
            if characteristic.value as! Bool == true {
                self.isDiscoBallPowerOn = true
                self.deviceIndicator.text = "Disco Ball ON"
                self.switchStatus.setTitle("Stop Party", forState: UIControlState.Normal)
                self.switchStatus.titleLabel?.textAlignment = NSTextAlignment.Center
            } else {
                self.isDiscoBallPowerOn = false
                self.deviceIndicator.text = "Disco Ball OFF"
                self.switchStatus.setTitle("Start Party", forState: UIControlState.Normal)
                self.switchStatus.titleLabel?.textAlignment = NSTextAlignment.Center
                }
        }
    }



// CONVENIENCE METHODS SUPPORTING BUTTON ACTIONS

func addMyAccessory() {
    if self.discoballAccessory != nil {
        print("addMyAccessory: discoball: \(self.discoballAccessory)")
         self.primaryHome?.addAccessory(self.discoballAccessory!, completionHandler: {(error) in
         if error != nil {
                print("Could not add \(self.discoballAccessory!.name) to \(self.primaryHome!.name)")
                print("error: \(error)")
            } else {
                print("Successfully added \(self.discoballAccessory!.name) to \(self.primaryHome!.name)")
                //
                // Set the delegate for the accessory so we can see updates to it
                //
                self.discoballAccessory!.delegate = self

                self.accessoryStatus.text = "\(self.discoballAccessory!.name) CONNECTED"
                //
                // CALL THE FUNCTION TO LIST THE SERVICES FOR THIS ACCESSORY
                //
                print("Services offerred...")
                self.listServices(self.discoballAccessory!)
                //
                // No need to continue searching
                //
                self.stopSearching()
                }
                        
         })
    } else {
            self.accessoryStatus.text = "No accessory identified to attach"
        }
}

// Bottom Button
func activateDiscoBall() {
//    print("User pressed \(self.switchStatus.titleLabel!.text) button")
    if self.discoBallPowerSwitch != nil {
        if isDiscoBallPowerOn == false {
            self.discoBallPowerSwitch?.writeValue(true, completionHandler: { (error)  in
                if error != nil {
                        print("Error setting power to Disco Ball: \(error)")
                    } else {
//                        print("Power to Disco Ball Set Successfully")
                        self.isDiscoBallPowerOn = true
                        self.deviceIndicator.text = "Disco Ball ON"
                        self.switchStatus.setTitle("Stop Party", forState: UIControlState.Normal)
                        self.switchStatus.titleLabel!.textAlignment = NSTextAlignment.Center
                    }
            })
            } else {
            self.discoBallPowerSwitch?.writeValue(false, completionHandler: { (error)  in
                if error != nil {
                        print("Error turning power OFF to Disco Ball: \(error)")
                    } else {
//                        print("Power to Disco Ball now OFF")
                        self.isDiscoBallPowerOn  = false
                        self.deviceIndicator.text = "Disco Ball OFF"
                        self.switchStatus.setTitle("Start Party", forState: UIControlState.Normal)
                        self.switchStatus.titleLabel!.textAlignment = NSTextAlignment.Center
                    }
            })
                }
    }
}


}



