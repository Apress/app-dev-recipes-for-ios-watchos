//
//  InterfaceController.swift
//  CoinToss WatchKit Extension
//
//  Created by Molly Maskrey on 12/14/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {


    @IBOutlet var button: WKInterfaceButton!
    @IBOutlet var coinImage: WKInterfaceImage!
    

    @IBAction func buttonPressed() {
        self.coinImage.setImageNamed("flip")
        let randomNumber = arc4random_uniform(2)  // random # between 0 and 1
        if randomNumber == 0 {
            self.coinImage.startAnimatingWithImagesInRange(NSRange(location: 1, length: 10), duration: 1, repeatCount: 2)
        } else  {
            self.coinImage.startAnimatingWithImagesInRange(NSRange(location: 1, length: 7), duration: 1, repeatCount: 2)
        }
    }
    
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        self.coinImage.stopAnimating()
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
