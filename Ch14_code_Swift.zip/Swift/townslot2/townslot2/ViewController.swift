//
//  ViewController.swift
//  townslot2
//
//  Created by Molly Maskrey on 11/10/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

import UIKit
import AudioToolbox


let userResetGame: String = "resetGame"
let kInitialCredits : Int = 100


class ViewController: UIViewController {

    //
    // PROPERTIES from OBJ-c to Swift
    //
    
    var thisBet : Int = 0
    var totalCredits : Int = 0
    var allowSpin: Bool = true
    var isSpinning: Bool = false
    var gameOver: Bool = false
    var stoppingPoints : [Double] = [95.0,35.0,-25.0,-85.0,-145.0,-210.0,-270.0,-330.0,-395.0]
    
    enum iPhoneType {
        case knotSelectedYet
        case kiPhone4S
        case kiPhone5
        case kiPhone6
        case kiPhone6Plus
    }
    var iphoneType : iPhoneType = .knotSelectedYet
    
    var topMostView : UIView?
    
    var shiftOverValue = 0.0
    
    var slotStripViewWheel1PosStart: CGRect?
    var slotStripViewWheel1PosEnd: CGRect?
    var slotStripViewWheel2PosStart: CGRect?
    var slotStripViewWheel2PosEnd: CGRect?
    var slotStripViewWheel3PosStart: CGRect?
    var slotStripViewWheel3PosEnd: CGRect?
    var slotStripViewWheel1PosComplete: CGRect?
    var slotStripViewWheel2PosComplete: CGRect?
    var slotStripViewWheel3PosComplete: CGRect?
    
    var winThisSpin : Int = 0
    
    var slotStripViewWheel1 : UIImageView?
    var slotStripViewWheel2 : UIImageView?
    var slotStripViewWheel3 : UIImageView?
    
    var greenLightSequenceImageView : UIImageView = UIImageView()
    var redLightSequenceImageView : UIImageView = UIImageView()

    var creditsLabel : UILabel?
    var betLabel : UILabel?
    var winLabel : UILabel?
    
    let spinButton = UIButton(frame: CGRectMake(0.0, 0.0, 65.0, 65.0))
    let betButton = UIButton(frame: CGRectMake(0.0, 0.0, 65.0, 65.0))
    let betMaxButton = UIButton(frame: CGRectMake(0.0, 0.0, 65.0, 65.0))

    var spinFileURLRef: CFURLRef?
    var spinSoundObject: SystemSoundID = 0
    var clickFileURLRef: CFURLRef?
    var clickSoundObject: SystemSoundID = 0
    var winFileURLRef: CFURLRef?
    var winSoundObject: SystemSoundID = 0
    var loseFileURLRef: CFURLRef?
    var loseSoundObject: SystemSoundID = 0
    
    var spin1: Int = 0
    var spin2: Int = 0
    var spin3: Int = 0
    var spinValue : Int = 0
    let numberOfIcons : Int = 9

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print("viewDidLoad")
        
        isSpinning	= false         // initially not spinning - NOTE this is not needed
                                    //    because it was set as an initializer...
        
        let nc: NSNotificationCenter = NSNotificationCenter.defaultCenter()
        nc.addObserver(self, selector: "resetGame", name: userResetGame, object: nil)
        print("Registered with notification center")
        
        let appSize: CGSize = UIScreen.mainScreen().bounds.size
        let appRect: CGRect = CGRectMake(0.0, 0.0, appSize.width, appSize.height)
        print("screen size: Width:  \(appRect.width), Height: \(appRect.height)")
        
        
        let contentView = UIView(frame: appRect)
        contentView.backgroundColor = UIColor.blackColor()
        self.view.addSubview(contentView)
        
        
        //
        // Determine iPhone type (4,5,6,6P) from screen size so we can
        // us that to correctly position
        if (appSize.width == 320.0) && (appSize.height == 480.0) {
            iphoneType = .kiPhone4S
            print("iPhone4S")
        }
        else {
            if (appSize.width == 320.0) && (appSize.height == 568.0) {
                iphoneType = .kiPhone5
                print("iPhone5")
            }
            else {
                if (appSize.width == 375.0) && (appSize.height == 667.0) {
                    iphoneType = .kiPhone6
                    print("iPhone6")
                }
                else {
                    if (appSize.width == 414.0) && (appSize.height == 736.0) {
                        iphoneType = .kiPhone6Plus
                        print("iPhone6 Plus")
                    }
                }
            }
        }
        
        
        switch iphoneType {
        case .kiPhone4S:
            topMostView = UIImageView(frame: CGRectMake(0.0, 0.0, 320.0, 480.0))
            topMostView?.backgroundColor = UIColor(patternImage: UIImage(named: "SlotFaceiPhoneBasic.png")!)
            print("iPhone 4S")
        case .kiPhone5:
            topMostView = UIImageView(frame: CGRectMake(0.0, 0.0, 320.0, 568.0))
            topMostView?.backgroundColor = UIColor(patternImage: UIImage(named: "SlotFaceiPhone5.png")!)
            print("iPhone 5")
        case .kiPhone6:
            topMostView = UIImageView(frame: CGRectMake(0.0, 0.0, 375.0, 667.0))
            topMostView?.backgroundColor = UIColor(patternImage: UIImage(named: "SlotFaceiPhone6.png")!)
            print("iPhone 6")
        case .kiPhone6Plus:
            topMostView = UIImageView(frame: CGRectMake(0.0, 0.0, 414.0, 736.0))
            topMostView?.backgroundColor = UIColor(patternImage: UIImage(named: "SlotFaceiPhone6Plus.png")!)
            print("iPhone 6 Plus")
        default:
            print("entered iphoneType set topMostView DEFAULT case")
        }
        
        
        // Slide the wheels over to the right (value) depending on screen size
        switch iphoneType {
            
            case .kiPhone4S:
                shiftOverValue = 0.0
            case .kiPhone5:
                shiftOverValue = 0.0
            case .kiPhone6:
                shiftOverValue = 30.0
            case .kiPhone6Plus:
                shiftOverValue = 50.0
            default:
                break
        }

        // SET UP SCORING LABELS
        creditsLabel = UILabel(frame: CGRectMake(0.0, 0.0, 75.0, 20.0))
        self.creditsLabel!.textAlignment = .Right
        self.creditsLabel!.backgroundColor = UIColor.blackColor()
        self.creditsLabel!.textColor = UIColor.redColor()
        self.creditsLabel!.font = UIFont.boldSystemFontOfSize(20)
        let totString: String = String(format: "%d", totalCredits)
        self.creditsLabel!.text = totString;
        
        
        betLabel = UILabel(frame: CGRectMake(0.0, 0.0, 25.0, 20.0))
        self.betLabel!.textAlignment = .Right
        self.betLabel!.backgroundColor = UIColor.blackColor()
        self.betLabel!.textColor = UIColor.redColor()
        self.betLabel!.font = UIFont.boldSystemFontOfSize(20)
        let betString: String = String(format: "%2d", totalCredits)
        self.betLabel!.text = betString;
        
        winLabel = UILabel(frame: CGRectMake(0.0, 0.0, 35.0, 20.0))
        self.winLabel!.textAlignment = .Right
        self.winLabel!.backgroundColor = UIColor.blackColor()
        self.winLabel!.textColor = UIColor.redColor()
        self.winLabel!.font = UIFont.boldSystemFontOfSize(20)
        let winString: String = String(format: "%d", totalCredits)
        self.winLabel!.text = winString;


        
        restoreUserSettings()
        
        
        slotStripViewWheel1PosEnd	= CGRectMake(33.0 + CGFloat(shiftOverValue), -2600.0, 90.0, 2900.0);
        slotStripViewWheel2PosEnd	= CGRectMake(116.0 + CGFloat(shiftOverValue), -2600.0, 90.0, 2900.0);
        slotStripViewWheel3PosEnd	= CGRectMake(199.0 + CGFloat(shiftOverValue), -2600.0, 90.0, 2900.0);
        
        slotStripViewWheel1 = UIImageView(frame: slotStripViewWheel1PosStart!)
        slotStripViewWheel1?.image = UIImage(named: "SlotStripLong.png")
        slotStripViewWheel2 = UIImageView(frame: slotStripViewWheel2PosStart!)
        slotStripViewWheel2?.image = UIImage(named: "SlotStripLong.png")
        slotStripViewWheel3 = UIImageView(frame: slotStripViewWheel3PosStart!)
        slotStripViewWheel3?.image = UIImage(named: "SlotStripLong.png")
        
        
        
        spinButton.setImage(UIImage(named: "spinButton.png"), forState: .Normal)
        spinButton.setImage(UIImage(named: "spinButtonPressed.png"), forState: .Highlighted)
        spinButton.addTarget(self, action: "spin", forControlEvents: .TouchUpInside)
        spinButton.addTarget(self, action: "makeButtonClick", forControlEvents: .TouchUpInside)
        
        betButton.setImage(UIImage(named: "betButton.png"), forState: .Normal)
        betButton.addTarget(self, action: "addToBet", forControlEvents: .TouchUpInside)
        betButton.addTarget(self, action: "makeButtonClick", forControlEvents: .TouchUpInside)
        
        
        betMaxButton.setImage(UIImage(named: "betMaxButton.png"), forState: .Normal)
        betMaxButton.addTarget(self, action: "addMaxToBet", forControlEvents: .TouchUpInside)
        betMaxButton.addTarget(self, action: "makeButtonClick", forControlEvents: .TouchUpInside)
        
        
        switch iphoneType {
        case .kiPhone4S, .kiPhone5:
            creditsLabel!.center = CGPointMake(93.0, 213.0)
            betLabel!.center = CGPointMake(160.0, 213.0)
            winLabel!.center = CGPointMake(220.0, 213.0)
            spinButton.center = CGPointMake(260.0, 300.0)
            betButton.center = CGPointMake(150.0, 300.0)
            betMaxButton.center = CGPointMake(65.0, 300.0)
            
        case .kiPhone6:
            creditsLabel!.center = CGPointMake(120.0, 216.0)
            betLabel!.center = CGPointMake(190.0, 216.0)
            winLabel!.center = CGPointMake(255.0, 216.0)
            spinButton.center = CGPointMake(290.0, 302.0)
            betButton.center = CGPointMake(190.0, 302.0)
            betMaxButton.center = CGPointMake(100.0, 302.0)
            
        case .kiPhone6Plus:
            creditsLabel!.center = CGPointMake(140.0, 212.0)
            betLabel!.center = CGPointMake(212.0, 212.0)
            winLabel!.center = CGPointMake(280.0, 212.0)
            spinButton.center = CGPointMake(320.0, 300.0)
            betButton.center = CGPointMake(220.0, 300.0)
            betMaxButton.center = CGPointMake(120.0, 300.0)
            
        default:
            break
        }
        
        
        

        
        contentView.addSubview(slotStripViewWheel1!)
        contentView.addSubview(slotStripViewWheel2!)
        contentView.addSubview(slotStripViewWheel3!)
        contentView.addSubview(topMostView!)
        // Note Order of buttons and labels ON TOP of TOPMOST VIEW
        contentView.addSubview(creditsLabel!)
        contentView.addSubview(betLabel!)
        contentView.addSubview(winLabel!)
        contentView.addSubview(spinButton)
        contentView.addSubview(betButton)
        contentView.addSubview(betMaxButton)
        
        
        
        
        // SET UP SOUNDS
        var mainBundle: CFBundleRef
        mainBundle = CFBundleGetMainBundle()
        
        // Get the URL to the sound file to play
        spinFileURLRef = CFBundleCopyResourceURL(mainBundle, "spinSound1" as CFString , "wav" as CFString , nil)
        AudioServicesCreateSystemSoundID(spinFileURLRef!, &spinSoundObject)
        
        clickFileURLRef = CFBundleCopyResourceURL(mainBundle, "click1" as CFString , "wav" as CFString , nil)
        AudioServicesCreateSystemSoundID(clickFileURLRef!, &clickSoundObject)
        
        winFileURLRef = CFBundleCopyResourceURL(mainBundle, "win" as CFString , "wav" as CFString , nil)
        AudioServicesCreateSystemSoundID(winFileURLRef!, &winSoundObject)
        
        loseFileURLRef = CFBundleCopyResourceURL(mainBundle, "youLose" as CFString , "wav" as CFString , nil)
        AudioServicesCreateSystemSoundID(loseFileURLRef!, &loseSoundObject)
        
        setupGreenLightSequence()
        setupRedLightSequence()
        
        updateLabels()
        
    }  // END VIEW_DID_LOAD *******
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    //
    // PORTED OBJ-C METHODS to FUNCS
    //
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    func addToBet() -> () {  // Null return OPTIONAL
        if thisBet < totalCredits {
            if self.thisBet < 10 {
                self.thisBet++
            }
            else {
                self.thisBet = 1
            }
            self.updateLabels()
            self.allowSpin = true
        }
        else {
            print("Can't bet more than you have left")
            self.thisBet = 0
            self.updateLabels()
            self.allowSpin = false
        }
    }
    func addMaxToBet() {
        if totalCredits == 0 {
            return
        }
        if totalCredits < 10 {
            self.thisBet = totalCredits
        }
        else {
            self.thisBet = 10
        }
        self.updateLabels()
    }
    
//
//   SPIN FUNCTION - This is where most of the activity takes place
//
    
    func spin() {
        
        print("SPIN called")
        // start flashing the red and green lights at the top of
        // the slot machine image on the device.
        startGreenLightAnimation()
        startRedLightAnimation()

        // If we're spinning, disable the buttons so the player can't cause
        // problems much like a real slot machine
        isSpinning = true
        spinButton.enabled = false
        betButton.enabled = false
        betMaxButton.enabled = false
    
        //  THE THREE SPINS - generate a random place to stop on our simulated 'wheel'
//        spin1 = Int(arc4random()) % numberOfIcons        // large number modulo the # of icons
//        spin2 = Int(arc4random()) % numberOfIcons        // large number modulo the # of icons
//        spin3 = Int(arc4random()) % numberOfIcons        // large number modulo the # of icons
        
        spin1 =  Int(arc4random_uniform(10000)) % numberOfIcons
        spin2 =  Int(arc4random_uniform(10000)) % numberOfIcons
        spin3 =  Int(arc4random_uniform(10000)) % numberOfIcons
        
        // Create a single number that tells us what the spin is
        // using a decimal scheme...one wheel is the hundreds position, one the tens and
        // the right-most the ones position.
        
        spinValue = (spin1 * 100) + (spin2 * 10) + spin3;
        
        print("The three wheel spins are: \(spin1) , \(spin2), \(spin3) ")
        print("SpinValue = \(spinValue)")
        
        slotStripViewWheel1PosComplete = CGRectMake(33.0 + CGFloat(shiftOverValue), CGFloat(stoppingPoints[Int(spin1)]), 90.0, 2900.0)
        slotStripViewWheel2PosComplete = CGRectMake(116.0 + CGFloat(shiftOverValue), CGFloat(stoppingPoints[Int(spin2)]), 90.0, 2900.0)
        slotStripViewWheel3PosComplete = CGRectMake(199.0 + CGFloat(shiftOverValue), CGFloat(stoppingPoints[Int(spin3)]), 90.0, 2900.0)
        
        // These three chunks of code setup the animation of each of the three 'wheels'
        // essentially, all were doing is moving the strips of fruit images up and down
        // to give the appearance of the three wheels spinning.
        //
        
        UIView.beginAnimations("wheel1", context: nil)
        UIView.setAnimationDelegate(self)
        UIView.setAnimationDidStopSelector("firstWheelReverse:")
        UIView.setAnimationCurve(.EaseIn)
        UIView.setAnimationDuration(2.0)
        slotStripViewWheel1!.frame = slotStripViewWheel1PosEnd!
        UIView.commitAnimations()
        
        UIView.beginAnimations("wheel2", context: nil)
        UIView.setAnimationDelegate(self)
        UIView.setAnimationDidStopSelector("secondWheelReverse:")
        UIView.setAnimationCurve(.EaseIn)
        UIView.setAnimationDuration(2.0)
        slotStripViewWheel2!.frame = slotStripViewWheel2PosEnd!
        UIView.commitAnimations()
        
        UIView.beginAnimations("wheel3", context: nil)
        UIView.setAnimationDelegate(self)
        UIView.setAnimationDidStopSelector("thirdWheelReverse:")
        UIView.setAnimationCurve(.EaseIn)
        UIView.setAnimationDuration(2.0)
        slotStripViewWheel3!.frame = slotStripViewWheel3PosEnd!
        UIView.commitAnimations()

        // SOUNDS
        AudioServicesPlaySystemSound(spinSoundObject)
    }
    
    func firstWheelReverse(animationID: String) {
        UIView.beginAnimations("reverseWheel1", context: nil)
        UIView.setAnimationCurve(.EaseOut)
        UIView.setAnimationDuration(1.0)
        slotStripViewWheel1!.frame = slotStripViewWheel1PosComplete!
        UIView.commitAnimations()
    }
    
    func secondWheelReverse(animationID: String) {
        UIView.beginAnimations("reverseWheel2", context: nil)
        UIView.setAnimationCurve(.EaseOut)
        UIView.setAnimationDuration(1.4)
        slotStripViewWheel2!.frame = slotStripViewWheel2PosComplete!
        UIView.commitAnimations()
    }
    
    func thirdWheelReverse(animationID: String) {
        UIView.beginAnimations("reverseWheel3", context: nil)
        UIView.setAnimationDelegate(self)
        UIView.setAnimationDidStopSelector("spinningHasStopped:")
        UIView.setAnimationCurve(.EaseOut)
        UIView.setAnimationDuration(1.8)
        slotStripViewWheel3!.frame = slotStripViewWheel3PosComplete!
        UIView.commitAnimations()
    }
    
    func spinningHasStopped(animationID: String) {
        print("Spinning Has Stopped")
        var allCreditsGone: Bool = false
        var winMultiplier: Int = 0
        isSpinning = false
        spinButton.enabled = true
        betButton.enabled = true
        betMaxButton.enabled = true
        
        //STOP LIGHTS
        stopGreenLightAnimation()
        stopRedLightAnimation()
        
        winMultiplier = calculateWinnings()
        // Lose
        if winMultiplier == 0 {
            self.totalCredits -= self.thisBet
            if self.totalCredits <= 0 {
                allCreditsGone = true
            }
            AudioServicesPlaySystemSound(self.loseSoundObject)
        }
        else {
            // Win
            self.totalCredits += (self.thisBet * winMultiplier)
            AudioServicesPlaySystemSound(self.winSoundObject)
        }
        
        updateLabels()
        if allCreditsGone {
            youLost()
        }
        
        saveGameState()
        
    }
    
    
    func resetGame() {
        print("ResetGame")
        makeButtonClick()
        winThisSpin = 0
        thisBet = 1
        totalCredits = kInitialCredits
        allowSpin = true
        gameOver = false
        updateLabels()
        saveGameState()
    }
    func updateLabels() {
        // TOTAL
        let totString: String = String(format: "%d", totalCredits)
        creditsLabel!.text = totString
        //BET
        let betString: String = String(format: "%d", thisBet)
        betLabel!.text = betString
        //WIN AMMOUNT
        let winString: String = String(format: "%d", winThisSpin)
        winLabel!.text = winString
        
    }
    func calculateWinnings() -> Int {
        var winMultiplier: Int = 1
        
        // Any single cherry
        if (spin1 == 2) && (spin2 != 2) && (spin3 != 2) {
            return 1
        }
        if (spin1 != 2) && (spin2 == 2) && (spin3 != 2) {
            return 1
        }
        if (spin1 != 2) && (spin2 != 2) && (spin3 == 2) {
            return 1
        }

        // Any DOUBLE cherry
        if (spin1 == 2) && (spin2 == 2) && (spin3 != 2) {
            return 3
        }
        if (spin1 != 2) && (spin2 == 2) && (spin3 == 2) {
            return 3
        }
        if (spin1 == 2) && (spin2 != 2) && (spin3 == 2) {
            return 3
        }
        
        // Three CHERRIES
        if (spin1 == 2) && (spin2 == 2) && (spin3 == 2) {
            return 150
        }
        
        switch spinValue {
        case 000:
            winMultiplier = 100
            // 3 Bars
            
        case 888:
            winMultiplier = 100
            // 3 sevens
            
        case 111, 222, 333, 444, 555, 666, 777:
            winMultiplier = 3       // 3 anything else --> 3X bet
            
        default:
            winMultiplier = 0       // anything else --> lose
        }
        return winMultiplier
    }
    
    
    func youLost()  {
        let alertController = UIAlertController(title: "Lost it All", message: "APress OK to play again.", preferredStyle: .Alert)
        let OKAction = UIAlertAction(title: "OK", style: .Default) { (action:UIAlertAction!) in
            self.resetGame()
        }
        alertController.addAction(OKAction)
        
        self.presentViewController(alertController, animated: true, completion:nil)
    }
    
    func setupGreenLightSequence() {
        var img1: UIImage
        var img2: UIImage
        var img3: UIImage
        var img4: UIImage
        
        if iphoneType == .kiPhone6Plus {
            img1 = UIImage(named: "100greenTop6P.png")!
            img2 = UIImage(named: "110greenTop6P.png")!
            img3 = UIImage(named: "111greenTop6P.png")!
            img4 = UIImage(named: "011greenTop6P.png")!
        }
        else {
            //smaller screen size
            img1 = UIImage(named: "100greenTop.png")!
            img2 = UIImage(named: "110greenTop.png")!
            img3 = UIImage(named: "111greenTop.png")!
            img4 = UIImage(named: "011greenTop.png")!
        }
        var images: [UIImage] = []
        images.append(img1)
        images.append(img2)
        images.append(img3)
        images.append(img4)

        greenLightSequenceImageView.animationImages = images
        greenLightSequenceImageView.animationRepeatCount = 0
        greenLightSequenceImageView.animationDuration = 0.5
        
        switch iphoneType {
        case .kiPhone4S:
            greenLightSequenceImageView.frame = CGRectMake(71, 1, 200, 20)
        case .kiPhone5:
            greenLightSequenceImageView.frame = CGRectMake(71, 1, 200, 20)
        case .kiPhone6:
            greenLightSequenceImageView.frame = CGRectMake(100, 1, 200, 20)
        case .kiPhone6Plus:
            greenLightSequenceImageView.frame = CGRectMake(114, 1, 200, 20)
        default: break
        }
    
    }
    
    
    func startGreenLightAnimation() {
        greenLightSequenceImageView.startAnimating()
        view.addSubview(greenLightSequenceImageView)
    }
    
    func stopGreenLightAnimation() {
        greenLightSequenceImageView.stopAnimating()
        greenLightSequenceImageView.removeFromSuperview()
    }
    
    func setupRedLightSequence() {
        var img1: UIImage
        var img2: UIImage
        var img3: UIImage
        var img4: UIImage
        var img5: UIImage
        
        if iphoneType == .kiPhone6Plus {
            img1 = UIImage(named: "001redBottom6P.png")!
            img2 = UIImage(named: "011redBottom6P.png")!
            img3 = UIImage(named: "111redBottom6P.png")!
            img4 = UIImage(named: "110redBottom6P.png")!
            img5 = UIImage(named: "100redBottom6P.png")!
        }
        else {
            //smaller screen size
            img1 = UIImage(named: "001redBottom.png")!
            img2 = UIImage(named: "011redBottom.png")!
            img3 = UIImage(named: "111redBottom.png")!
            img4 = UIImage(named: "110redBottom.png")!
            img5 = UIImage(named: "100redBottom.png")!
        }
        var images: [UIImage] = []
        images.append(img1)
        images.append(img2)
        images.append(img3)
        images.append(img4)
        images.append(img5)

        
        redLightSequenceImageView.animationImages = images
        redLightSequenceImageView.animationRepeatCount = 0
        redLightSequenceImageView.animationDuration = 0.5
        
        switch iphoneType {
        case .kiPhone4S:
            redLightSequenceImageView.frame = CGRectMake(71, 1, 200, 20)
        case .kiPhone5:
            redLightSequenceImageView.frame = CGRectMake(71, 1, 200, 20)
        case .kiPhone6:
            redLightSequenceImageView.frame = CGRectMake(100, 1, 200, 20)
        case .kiPhone6Plus:
            redLightSequenceImageView.frame = CGRectMake(114, 1, 200, 20)
        default: break
        }
        
    }
    func startRedLightAnimation() {
        redLightSequenceImageView.startAnimating()
        view.addSubview(redLightSequenceImageView)
    }
    
    func stopRedLightAnimation() {
        redLightSequenceImageView.stopAnimating()
        redLightSequenceImageView.removeFromSuperview()
    }
    
    func makeButtonClick() {
        AudioServicesPlaySystemSound(clickSoundObject)
    }
    func saveGameState() {
        print("Calling Save Game State")
        
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.setInteger(spin1, forKey: "spin1")
        defaults.setInteger(spin2, forKey: "spin2")
        defaults.setInteger(spin3, forKey: "spin3")
        defaults.setInteger(winThisSpin, forKey: "winthisspin")
        defaults.setInteger(thisBet, forKey: "thisbet")
        defaults.setInteger(totalCredits, forKey: "totalcredits")
        defaults.synchronize()
    }
    
    func restoreUserSettings() {
        let defaults = NSUserDefaults.standardUserDefaults()
        // Determine if values have been previously saved and if so,
        // load them in. Otherwise, initialize the game
        if (defaults.objectForKey("spin1") != nil) {
            spin1 = defaults.objectForKey("spin1") as! Int
            slotStripViewWheel1PosStart = CGRectMake(33.0 + CGFloat(shiftOverValue), CGFloat(spin1), 90.0, 2900.0)
            slotStripViewWheel2PosStart = CGRectMake(116.0 + CGFloat(shiftOverValue), CGFloat(defaults.objectForKey("spin2") as! Int), 90.0, 2900.0)
            slotStripViewWheel3PosStart = CGRectMake(199.0 + CGFloat(shiftOverValue), CGFloat(defaults.objectForKey("spin3") as! Int), 90.0, 2900.0)
            winThisSpin = defaults.objectForKey("winthisspin") as! Int
            thisBet = defaults.objectForKey("thisbet") as! Int
            totalCredits = defaults.objectForKey("totalcredits") as! Int
        } else {
            print("initializing game - no data was stored")
            slotStripViewWheel1PosStart = CGRectMake(33.0 + CGFloat(shiftOverValue), 95.0, 90.0, 2900.0)
            slotStripViewWheel2PosStart = CGRectMake(116.0 + CGFloat(shiftOverValue), 95.0, 90.0, 2900.0)
            slotStripViewWheel3PosStart = CGRectMake(199.0 + CGFloat(shiftOverValue), 95.0, 90.0, 2900.0)
            self.resetGame()
        }
    }
    
//
// END VIEW CONTROLLER CLASS
//
    
}

