//
//  AppDelegate.m
//  SlotMachine
//
//  Created by Molly Maskrey on 9/23/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

@implementation AppDelegate

@synthesize window;
@synthesize viewController;



- (void)applicationDidFinishLaunching:(UIApplication *)application {
    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}



@end

