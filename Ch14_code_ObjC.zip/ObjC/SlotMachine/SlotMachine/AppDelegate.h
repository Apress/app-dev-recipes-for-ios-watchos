//
//  AppDelegate.h
//  SlotMachine
//
//  Created by Molly Maskrey on 9/23/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;



@interface AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ViewController *viewController;

@end


