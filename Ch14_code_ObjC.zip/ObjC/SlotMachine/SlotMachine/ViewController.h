//
//  ViewController.h
//  SlotMachine
//
//  Created by Molly Maskrey on 9/23/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <AudioToolbox/AudioToolbox.h>

#import	"AppDelegate.h"


#define	numberOfIcons	9

#define	kInitialCredits	100


@class	SetupViewController;

@interface ViewController : UIViewController  {

    UIImageView	*greenLightSequenceImageView;
    UIImageView	*redLightSequenceImageView;
    
    SetupViewController	*setupViewController;
    BOOL	allowSpin;
    BOOL	isSpinning;
    BOOL	gameOver;
    UIView	*contentView;
    CGRect	slotStripViewWheel1PosStart;
    CGRect	slotStripViewWheel1PosEnd;
    CGRect	slotStripViewWheel2PosStart;
    CGRect	slotStripViewWheel2PosEnd;
    CGRect	slotStripViewWheel3PosStart;
    CGRect	slotStripViewWheel3PosEnd;
    CGRect	slotStripViewWheel1PosComplete;
    CGRect	slotStripViewWheel2PosComplete;
    CGRect	slotStripViewWheel3PosComplete;
    
    // These are the three buttons, 2 used for betting and one to start the spin
    UIButton	*spinButton;
    UIButton	*betButton;
    UIButton	*betMaxButton;
    
    // These are the 3 numbers shown in red at about the center of the display
    UILabel		*creditsLabel;
    UILabel		*betLabel;
    UILabel		*winLabel;
    
    // These 3 image views hold the slot icons on a long strip that we
    // move underneath the main Slot machine frame to give a sense of spinning.
    UIImageView	*slotStripViewWheel1;
    UIImageView	*slotStripViewWheel2;
    UIImageView	*slotStripViewWheel3;
    
    
    // These are used to hold the random values for each virtual wheel
    // and the adjusted value of all three.
    NSUInteger	spin1;
    NSUInteger	spin2;
    NSUInteger	spin3;
    NSUInteger	spinValue;
    
    // properties that hold the credit, bet and winnings values
    int			winThisSpin;
    int			thisBet;
    int			totalCredits;
    
    // URL referene and sound object IDs for spinning, button click, winning and losing
    CFURLRef        spinFileURLRef;
    SystemSoundID    spinSoundObject;
    CFURLRef        clickFileURLRef;
    SystemSoundID    clickSoundObject;
    CFURLRef        winFileURLRef;
    SystemSoundID    winSoundObject;
    CFURLRef        loseFileURLRef;
    SystemSoundID    loseSoundObject;
    
    float	stoppingPoints[9];
}


@property	(nonatomic,retain) UIImageView	*greenLightSequenceImageView;
@property	(nonatomic,retain) UIImageView	*redLightSequenceImageView;

@property	(nonatomic,retain) SetupViewController	*setupViewController;

@property	(nonatomic, retain) UILabel	*creditsLabel;
@property	(nonatomic, retain) UILabel	*betLabel;
@property	(nonatomic, retain) UILabel	*winLabel;

@property	(nonatomic,retain) UIButton *spinButton;
@property	(nonatomic,retain) UIButton *betButton;
@property	(nonatomic,retain) UIButton	*betMaxButton;

@property	(nonatomic) BOOL	allowSpin;
@property	(nonatomic)	BOOL	gameOver;
@property	(nonatomic)	BOOL	isSpinning;

@property (readwrite)    CFURLRef        spinFileURLRef;
@property (readonly)    SystemSoundID    spinSoundObject;
@property (readwrite)    CFURLRef        clickFileURLRef;
@property (readonly)    SystemSoundID    clickSoundObject;
@property (readwrite)    CFURLRef        winFileURLRef;
@property (readonly)    SystemSoundID    winSoundObject;
@property (readwrite)    CFURLRef        loseFileURLRef;
@property (readonly)    SystemSoundID    loseSoundObject;

@property (nonatomic)	int		winThisSpin;
@property (nonatomic)	int		thisBet;
@property (nonatomic)	int		totalCredits;

@property (nonatomic, retain) UIView	*contentView;
@property (nonatomic) CGRect	slotStripViewWheel1PosStart;
@property (nonatomic) CGRect	slotStripViewWheel1PosEnd;
@property (nonatomic) CGRect	slotStripViewWheel2PosStart;
@property (nonatomic) CGRect	slotStripViewWheel2PosEnd;
@property (nonatomic) CGRect	slotStripViewWheel3PosStart;
@property (nonatomic) CGRect	slotStripViewWheel3PosEnd;
@property (nonatomic) CGRect	slotStripViewWheel1PosComplete;
@property (nonatomic) CGRect	slotStripViewWheel2PosComplete;
@property (nonatomic) CGRect	slotStripViewWheel3PosComplete;

@property (nonatomic, retain)	UIImageView	*slotStripViewWheel1;
@property (nonatomic, retain)	UIImageView	*slotStripViewWheel2;
@property (nonatomic, retain)	UIImageView	*slotStripViewWheel3;

@property (nonatomic, retain)	UIImageView	*topMostView;

typedef enum {
    kiPhone4S,
    kiPhone5,
    kiPhone6,
    kiPhone6Plus
} iPhoneType;


@property (nonatomic)    iPhoneType iphoneType;

-(void)spin;
-(void)makeButtonClick;
-(void)saveGameState;
-(void)restoreUserSettings;
-(int)calculateWinnings;
-(void)updateLabels;
-(void)youLost;
-(void)resetGame;

// Animations of the lights on top of the machine
-(void)setupGreenLightSequence;
-(void)startGreenLightAnimation;
-(void)stopGreenLightAnimation;
-(void)setupRedLightSequence;
-(void)startRedLightAnimation;
-(void)stopRedLightAnimation;


@end

