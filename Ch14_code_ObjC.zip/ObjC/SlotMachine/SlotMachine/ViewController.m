//
//  ViewController.m
//  SlotMachine
//
//  Created by Molly Maskrey on 9/23/15.
//  Copyright © 2015 Global Tek Labs. All rights reserved.
//

#import	<AudioToolbox/AudioToolbox.h>

#import "ViewController.h"

@implementation ViewController


@synthesize	setupViewController;
@synthesize	greenLightSequenceImageView;
@synthesize	redLightSequenceImageView;


@synthesize	gameOver;
@synthesize allowSpin;
@synthesize	isSpinning;
@synthesize spinButton;

@synthesize	betButton;
@synthesize betMaxButton;

@synthesize winThisSpin;
@synthesize thisBet;
@synthesize	totalCredits;

@synthesize	creditsLabel;
@synthesize	betLabel;
@synthesize	winLabel;

@synthesize	contentView;
@synthesize	slotStripViewWheel1PosStart;
@synthesize	slotStripViewWheel1PosEnd;
@synthesize	slotStripViewWheel2PosStart;
@synthesize	slotStripViewWheel2PosEnd;
@synthesize	slotStripViewWheel3PosStart;
@synthesize	slotStripViewWheel3PosEnd;
@synthesize slotStripViewWheel1PosComplete;
@synthesize slotStripViewWheel2PosComplete;
@synthesize slotStripViewWheel3PosComplete;

@synthesize	slotStripViewWheel1;
@synthesize	slotStripViewWheel2;
@synthesize	slotStripViewWheel3;
@synthesize topMostView;

@synthesize spinFileURLRef;
@synthesize spinSoundObject;
@synthesize clickFileURLRef;
@synthesize clickSoundObject;
@synthesize winFileURLRef;
@synthesize winSoundObject;
@synthesize loseFileURLRef;
@synthesize loseSoundObject;

@synthesize iphoneType;

//NSNotificationCenter messages
NSString * const userResetGame = @"resetGame";

// delta value used to move over the wheels
float shiftOverValue = 0.0;


// By setting this the return value of this method to YES, the
// UIViewController will hide the small status bar at the top
// allowing more use space for the slot graphics.
-(BOOL)prefersStatusBarHidden{
    return YES;
}

// Used to set the amount of credits that we bet on the next spin
-(void)addToBet
{
    if (thisBet < totalCredits) {
        if (self.thisBet < 10)
        {
            self.thisBet++;		// bump bet
        } else
            self.thisBet = 1;
        [self updateLabels];
        self.allowSpin = YES;
    }else { // can't bet more than what you have left
        NSLog(@"Can't bet more than you have left");
        self.thisBet = 0;
        [self updateLabels];
        self.allowSpin = NO;
    }
    
}

// Default to the max bet which is 10 credits
-(void)addMaxToBet
{
    if (totalCredits == 0) return;	// can't bet
    if (totalCredits < 10) {
        self.thisBet = totalCredits;
    }
    else {
        self.thisBet = 10;
    }
    
    [self updateLabels];
    
}


//
// The primary method called when the device loads the view
// Here, we set up pretty much everything to begin playing the game
// NSLog statements are used to show information to the console periodiclly
// as things happen (the program runs) to let us know what's going on.
//
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib
    NSLog(@"viewDidLoad");
    
    isSpinning	= NO;		// initially not spinning;
    
    stoppingPoints[0] = 95.0;
    stoppingPoints[1] = 35.0;
    stoppingPoints[2] = -25.0;
    stoppingPoints[3] = -85.0;
    stoppingPoints[4] = -145.0;
    stoppingPoints[5] = -210.0;
    stoppingPoints[6] = -270.0;
    stoppingPoints[7] = -330.0;
    stoppingPoints[8] = -395.0;
    
    //SETUP NOTIFICATION CENTER
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(resetGame) name:userResetGame object:nil];
    NSLog(@"Registered with notification center");
    
    // *** Create the MAIN WINDOW
    CGSize	appSize	= [UIScreen mainScreen].bounds.size;
    CGRect  appRect = CGRectMake(0.0, 0.0, appSize.width, appSize.height);
    
    NSLog(@"screen size: Width:  %f, Height: %f",appSize.width,appSize.height);
    
    //
    // Determine iPhone type (4,5,6,6P) from screen size so we can
    // us that to correctly position
    if ((appSize.width == 320.0) && (appSize.height == 480.0)) {
        iphoneType = kiPhone4S;
        NSLog(@"iPhone4S");
    } else if ((appSize.width == 320.0) && (appSize.height == 568.0)) {
        iphoneType = kiPhone5;
        NSLog(@"iPhone5");
    } else if ((appSize.width == 375.0) && (appSize.height == 667.0)) {
        iphoneType = kiPhone6;
        NSLog(@"iPhone6");
    } else if ((appSize.width == 414.0) && (appSize.height == 736.0)) {
        iphoneType = kiPhone6Plus;
        NSLog(@"iPhone6 Plus");
    }
    
    contentView = [[UIView alloc]	initWithFrame:appRect];
    contentView.backgroundColor = [UIColor blackColor];
    [self.view	addSubview:contentView];
    
    // Pick Slot Face Image based on screen size
    switch (iphoneType) {
        case kiPhone4S:
            topMostView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f,0.0f,320.0f,480.0f)];
            [topMostView	setImage:[UIImage	imageNamed:@"SlotFaceiPhoneBasic.png"]];
            break;
        case kiPhone5:
            topMostView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f,0.0f,320.0f,568.0f)];
            [topMostView	setImage:[UIImage	imageNamed:@"SlotFaceiPhone5.png"]];
            break;
        case kiPhone6:
            topMostView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f,0.0f,375.0f,667.0f)];
            [topMostView	setImage:[UIImage	imageNamed:@"SlotFaceiPhone6.png"]];
            break;
        case kiPhone6Plus:
            topMostView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f,0.0f,414.0f,736.0f)];
            [topMostView	setImage:[UIImage	imageNamed:@"SlotFaceiPhone6Plus.png"]];
            break;
            
        default:
            break;
    }
    
        
    // See if the user played before and pull up last wheel positions
    
    NSMutableArray	*userData;
    userData = [[NSUserDefaults standardUserDefaults] objectForKey:@"gameState"];
    
    // Slide the wheels over to the right (value) depending on screen size
    switch (iphoneType) {
        case kiPhone4S:
        case kiPhone5:
            break;
        case kiPhone6:
            shiftOverValue = 30.0;
            break;
        case kiPhone6Plus:
            shiftOverValue = 50.0;
            break;
            
        default:
            break;
    }
    
    if ([userData count] == 6)	// if data is present, then the game state was saved previously
    {
        
        slotStripViewWheel1PosStart	= CGRectMake(33.0f + shiftOverValue, stoppingPoints[[[userData objectAtIndex:0]   intValue]], 90.0f, 2900.0f);
        slotStripViewWheel2PosStart	= CGRectMake(116.0f + shiftOverValue, stoppingPoints[[[userData objectAtIndex:1]   intValue]], 90.0f, 2900.0f);
        slotStripViewWheel3PosStart	= CGRectMake(199.0f + shiftOverValue, stoppingPoints[[[userData objectAtIndex:2]   intValue]], 90.0f, 2900.0f);
        
        self.winThisSpin = [[userData	objectAtIndex:3] intValue];
        self.thisBet	= [[userData	objectAtIndex:4] intValue];
        self.totalCredits = [[userData	objectAtIndex:5] intValue];
        
    } else {	// if not any data, then restart game state
        
        NSLog(@"initializing game - no data was stored");
        
        slotStripViewWheel1PosStart	= CGRectMake(33.0f + shiftOverValue, 95.0f, 90.0f, 2900.0f);
        slotStripViewWheel2PosStart	= CGRectMake(116.0f + shiftOverValue, 95.0f, 90.0f, 2900.0f);
        slotStripViewWheel3PosStart	= CGRectMake(199.0f + shiftOverValue, 95.0f, 90.0f, 2900.0f);
        
        [self resetGame];
    }
    // set up the slot wheel positions that are not saved...i.e. the end position where we reverse the wheel
    // to make it look like a long spin
    
    slotStripViewWheel1PosEnd	= CGRectMake(33.0f + shiftOverValue, -2600.0f, 90.0f, 2900.0f);
    slotStripViewWheel2PosEnd	= CGRectMake(116.0f + shiftOverValue, -2600.0f, 90.0f, 2900.0f);
    slotStripViewWheel3PosEnd	= CGRectMake(199.0f + shiftOverValue, -2600.0f, 90.0f, 2900.0f);
    
    slotStripViewWheel1  = [[UIImageView alloc] initWithFrame:slotStripViewWheel1PosStart];
    [slotStripViewWheel1	setImage:[UIImage	imageNamed:@"SlotStripLong.png"]];
    
    slotStripViewWheel2  = [[UIImageView alloc] initWithFrame:slotStripViewWheel2PosStart];
    [slotStripViewWheel2	setImage:[UIImage	imageNamed:@"SlotStripLong.png"]];
    
    slotStripViewWheel3  = [[UIImageView alloc] initWithFrame:slotStripViewWheel3PosStart];
    [slotStripViewWheel3	setImage:[UIImage	imageNamed:@"SlotStripLong.png"]];
    
    
    // SET UP SCORING LABELS
    // CREDITS
    
    
    creditsLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 75.0f, 20.0f)];
    self.creditsLabel.textAlignment = NSTextAlignmentRight;
    self.creditsLabel.backgroundColor = [UIColor blackColor];
    self.creditsLabel.textColor = [UIColor redColor];
    self.creditsLabel.font = [UIFont boldSystemFontOfSize:20];
    NSString *totString = [[NSString alloc] initWithFormat:@"%d",totalCredits];
    
    // THIS BET
    betLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 25.0f, 20.0f)];
    self.betLabel.textAlignment = NSTextAlignmentRight;
    self.betLabel.backgroundColor = [UIColor blackColor];
    self.betLabel.textColor = [UIColor redColor];
    self.betLabel.font = [UIFont boldSystemFontOfSize:20];
    NSString *betString = [[NSString alloc] initWithFormat:@"%d",thisBet];
    
    // THIS SPIN'S WIN VALUE
    winLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 35.0f, 20.0f)];
    self.winLabel.textAlignment = NSTextAlignmentRight;
    self.winLabel.backgroundColor = [UIColor blackColor];
    self.winLabel.textColor = [UIColor redColor];
    self.winLabel.font = [UIFont boldSystemFontOfSize:20];
    NSString *winString = [[NSString alloc] initWithFormat:@"%d",winThisSpin];
    
    
    // SET UP BUTTONS
    // SPIN BUTTON
    spinButton = [[UIButton	alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 65.0f, 65.0f)];
    [spinButton	setBackgroundImage:[UIImage		imageNamed:@"spinButton.png"]	forState:UIControlStateNormal];
    [spinButton	setBackgroundImage:[UIImage		imageNamed:@"spinButtonPressed.png"]	forState:UIControlStateHighlighted];
    [spinButton	addTarget:self action:@selector(spin) forControlEvents:UIControlEventTouchUpInside];
    [spinButton	addTarget:self action:@selector(makeButtonClick) forControlEvents:UIControlEventTouchDown];
    
    //BET BUTTON
    betButton = [[UIButton	alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 65.0f, 65.0f)];
    [betButton	setBackgroundImage:[UIImage		imageNamed:@"betButton.png"]	forState:UIControlStateNormal];
    [betButton	addTarget:self action:@selector(addToBet) forControlEvents:UIControlEventTouchUpInside];
    [betButton	addTarget:self action:@selector(makeButtonClick) forControlEvents:UIControlEventTouchDown];
    
    //BET MAX BUTTON
    betMaxButton = [[UIButton	alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 65.0f, 65.0f)];
    [betMaxButton	setBackgroundImage:[UIImage		imageNamed:@"betMaxButton.png"]	forState:UIControlStateNormal];
    [betMaxButton	addTarget:self action:@selector(addMaxToBet) forControlEvents:UIControlEventTouchUpInside];
    [betMaxButton	addTarget:self action:@selector(makeButtonClick) forControlEvents:UIControlEventTouchDown];
    
    // Pick based on screen size
    switch (iphoneType) {
        case kiPhone4S:
        case kiPhone5:
            [creditsLabel	setCenter:CGPointMake(93.0f,213.0f)];
            [betLabel	setCenter:CGPointMake(160.0f,213.0f)];
            [winLabel	setCenter:CGPointMake(220.0f,213.0f)];
            [spinButton	setCenter:CGPointMake(260.0f,300.0f)];
            [betButton	setCenter:CGPointMake(150.0f,300.0f)];
            [betMaxButton	setCenter:CGPointMake(65.0f,300.0f)];
            break;
        case kiPhone6:
            [creditsLabel	setCenter:CGPointMake(120.0f,216.0f)];
            [betLabel	setCenter:CGPointMake(190.0f,216.0f)];
            [winLabel	setCenter:CGPointMake(255.0f,216.0f)];
            [spinButton	setCenter:CGPointMake(290.0f,302.0f)];
            [betButton	setCenter:CGPointMake(190.0f,302.0f)];
            [betMaxButton	setCenter:CGPointMake(100.0f,302.0f)];
            break;
        case kiPhone6Plus:
            [creditsLabel	setCenter:CGPointMake(140.0f,212.0f)];
            [betLabel	setCenter:CGPointMake(212.0f,212.0f)];
            [winLabel	setCenter:CGPointMake(280.0f,212.0f)];
            [spinButton	setCenter:CGPointMake(320.0f,300.0f)];
            [betButton	setCenter:CGPointMake(220.0f,300.0f)];
            [betMaxButton	setCenter:CGPointMake(120.0f,300.0f)];
            break;
            
        default:
            break;
    }
    self.creditsLabel.text = totString;
    self.betLabel.text = betString;
    self.winLabel.text = winString;

    [contentView	addSubview:slotStripViewWheel1];
    [contentView	addSubview:slotStripViewWheel2];
    [contentView	addSubview:slotStripViewWheel3];
    [contentView addSubview:topMostView];

    [contentView	addSubview:spinButton];
    [contentView	addSubview:betButton];
    [contentView	addSubview:betMaxButton];
    [contentView	addSubview:creditsLabel];
    [contentView	addSubview:betLabel];
    [contentView	addSubview:winLabel];
    

    // restore user setting
//    [self restoreUserSettings];		// things like spin, score, etc
    
    
    // SET UP SOUNDS
    CFBundleRef mainBundle;
    mainBundle = CFBundleGetMainBundle ();
    
    // Get the URL to the sound file to play
    spinFileURLRef  =    CFBundleCopyResourceURL (
                                                  mainBundle,
                                                  CFSTR ("spinSound1"),
                                                  CFSTR ("wav"),
                                                  NULL
                                                  );
    clickFileURLRef  =    CFBundleCopyResourceURL (
                                                   mainBundle,
                                                   CFSTR ("click1"),
                                                   CFSTR ("wav"),
                                                   NULL
                                                   );
    winFileURLRef  =    CFBundleCopyResourceURL (
                                                 mainBundle,
                                                 CFSTR ("win"),
                                                 CFSTR ("wav"),
                                                 NULL
                                                 );
    loseFileURLRef  =    CFBundleCopyResourceURL (
                                                  mainBundle,
                                                  CFSTR ("youLose"),
                                                  CFSTR ("wav"),
                                                  NULL
                                                  );		
    // Create a system sound object representing the sound file
    AudioServicesCreateSystemSoundID (
                                      spinFileURLRef,
                                      &spinSoundObject
                                      );
    AudioServicesCreateSystemSoundID (
                                      clickFileURLRef,
                                      &clickSoundObject
                                      );
    AudioServicesCreateSystemSoundID (
                                      winFileURLRef,
                                      &winSoundObject
                                      );
    AudioServicesCreateSystemSoundID (
                                      loseFileURLRef,
                                      &loseSoundObject
                                      );

    //SETUP LIGHTS
    [self setupGreenLightSequence];
    [self setupRedLightSequence];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





// GAME PLAY METHODS


// Spin, of course, does the most of the work when the player clicks on the 'spin' button.
// in the viewDidLoad method above, you can see when we create the spin button, that we set
// the "selector" to 'spin' which is this function. This is the example of event driven programming,
// when the spin button event occurs, iOS (the operating system) calls this function to be executed.

-(void)spin
{
    
    // start flashing the red and green lights at the top of
    // the slot machine image on the device.
    [self startGreenLightAnimation];
    [self startRedLightAnimation];
    
    
    // If we're spinning, disable the buttons so the player can't cause
    // problems much like a real slot machine
    
    isSpinning = YES;
    spinButton.enabled = NO;
    betButton.enabled = NO;
    betMaxButton.enabled = NO;

    //  THE THREE SPINS - generate a random place to stop on our simulated 'wheel'
    
    spin1 = arc4random() % numberOfIcons;				// large number modulo the # of icons
    spin2 = arc4random() % numberOfIcons;				// large number modulo the # of icons
    spin3 = arc4random() % numberOfIcons;				// large number modulo the # of icons
    
    // Create a single number that tells us what the spin is
    // using a decimal scheme...one wheel is the hundreds position, one the tens and
    // the right-most the ones position.
    
    spinValue = (spin1 * 100) + (spin2 * 10) + spin3;
    
    
    
    NSLog(@"The three wheel spins are: %lu, %lu, %lu",(unsigned long)spin1,(unsigned long)spin2,(unsigned long)spin3);
    NSLog(@"Spin Value = %lu", (unsigned long)spinValue);

    slotStripViewWheel1PosComplete	= CGRectMake(33.0f + shiftOverValue, stoppingPoints[spin1], 90.0f, 2900.0f);
    slotStripViewWheel2PosComplete	= CGRectMake(116.0f + shiftOverValue, stoppingPoints[spin2], 90.0f, 2900.0f);
    slotStripViewWheel3PosComplete	= CGRectMake(199.0f + shiftOverValue, stoppingPoints[spin3], 90.0f, 2900.0f);

    
    // These three chunks of code setup the animation of each of the three 'wheels'
    // essentially, all were doing is moving the strips of fruit images up and down
    // to give the appearance of the three wheels spinning.
    //
    [UIView	beginAnimations:@"wheel1" context:nil];
    [UIView	setAnimationDelegate:self];
    [UIView	setAnimationDidStopSelector:@selector(firstWheelReverse:)];
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseIn];
    [UIView	setAnimationDuration:2.0];
    [slotStripViewWheel1	setFrame:slotStripViewWheel1PosEnd];
    [UIView	commitAnimations];
    
    [UIView	beginAnimations:@"wheel2" context:nil];
    [UIView	setAnimationDelegate:self];
    [UIView	setAnimationDidStopSelector:@selector(secondWheelReverse:)];
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseIn];
    [UIView	setAnimationDuration:2.0];
    [slotStripViewWheel2	setFrame:slotStripViewWheel2PosEnd];
    [UIView	commitAnimations];
    
    [UIView	beginAnimations:@"wheel3" context:nil];
    [UIView	setAnimationDelegate:self];
    [UIView	setAnimationDidStopSelector:@selector(thirdWheelReverse:)];
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseIn];
    [UIView	setAnimationDuration:2.0];
    [slotStripViewWheel3	setFrame:slotStripViewWheel3PosEnd];
    [UIView	commitAnimations];	
    
    
    // SOUNDS
    AudioServicesPlaySystemSound (self.spinSoundObject);
    
} // end SPIN method



//
// Because we are using finite length strips of image to simulate a continuous
// 'wheel', to get that sense of spinning, when we reach the end of a strip, we
// just reverse it and move it the other way hoping the details of what we're doing
// aren't visible on the screen to the player.

- (void)firstWheelReverse:(NSString *)animationID  {
    [UIView	beginAnimations:@"reverseWheel1" context:nil];
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseOut];
    [UIView	setAnimationDuration:1.0];
    [slotStripViewWheel1	setFrame:slotStripViewWheel1PosComplete];
    [UIView	commitAnimations];
}
- (void)secondWheelReverse:(NSString *)animationID  {
    [UIView	beginAnimations:@"reverseWheel2" context:nil];
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseOut];
    [UIView	setAnimationDuration:1.4];
    [slotStripViewWheel2	setFrame:slotStripViewWheel2PosComplete];
    [UIView	commitAnimations];
}
- (void)thirdWheelReverse:(NSString *)animationID  {		// Assume third wheel is the last to stop
    NSLog(@"Spinning Has Stopped");
    [UIView	beginAnimations:@"reverseWheel3" context:nil];
    [UIView	setAnimationDelegate:self];
    [UIView	setAnimationDidStopSelector:@selector(spinningHasStopped:)];
    
    [UIView	setAnimationCurve: UIViewAnimationCurveEaseOut];
    [UIView	setAnimationDuration:1.8];
    [slotStripViewWheel3	setFrame:slotStripViewWheel3PosComplete];
    [UIView	commitAnimations];
}


//
// When the animation has completed, this method executes.
// we enable the buttons again so the player can continue,
// play sounds, stop flashing the lights, etc.
//
-(void)spinningHasStopped:(NSString *)animationID
{
    
    int	winMultiplier;
    NSLog(@"spinningHasStopped CALLED");
    isSpinning = NO;
    spinButton.enabled = YES;
    betButton.enabled = YES;
    betMaxButton.enabled = YES;
    
    //STOP LIGHTS
    [self stopGreenLightAnimation];
    [self stopRedLightAnimation];
    
    
    // CHECK FOR WIN
    
    winMultiplier = [self calculateWinnings];
    // Lose
    if (winMultiplier == 0) {
        self.totalCredits -= self.thisBet;
        AudioServicesPlaySystemSound (self.loseSoundObject);
    } else { // Win
        self.totalCredits += (self.thisBet * winMultiplier);
        AudioServicesPlaySystemSound (self.winSoundObject);
    }
    
    [self updateLabels];
    // save state
    [self saveGameState ];
}



-(void)resetGame
{
    NSLog(@"RESET GAME");
    [self makeButtonClick];
    self.winThisSpin = 0;
    self.thisBet = 1;
    self.totalCredits = kInitialCredits;
    self.allowSpin = YES;
    self.gameOver = NO;
    [self updateLabels];
    // save state - in case user exits immediately after a reset either from alert or info panel
    [self saveGameState];
    
}


//
// This method posts the values for bet, total credits and win amount to the
// display on the slot machine front panel image.
//
-(void)updateLabels;
{
    //TOTAL
    NSString *totString = [[NSString alloc] initWithFormat:@"%d", totalCredits];
    [creditsLabel	setText:totString];
    //BET
    NSString *betString = [[NSString alloc] initWithFormat:@"%d", thisBet];
    [betLabel	setText:betString];
    //WIN AMMOUNT
    NSString *winString = [[NSString alloc] initWithFormat:@"%d", winThisSpin];
    [winLabel	setText:winString];
}

//
// Here is where you can change how you want to pay out to the
// player depending on the spin
//
-(int)calculateWinnings
{
    int	winMultiplier;
    
    // Any single cherry
    if ((spin1  == 2) && (spin2 != 2) && (spin3 != 2)) return 1;
    if ((spin1  != 2) && (spin2 == 2) && (spin3 != 2)) return 1;
    if ((spin1  != 2) && (spin2 != 2) && (spin3 == 2)) return 1;
    
    // Any DOUBLE cherry
    if ((spin1  == 2) && (spin2 == 2) && (spin3 != 2)) return 3;
    if ((spin1  != 2) && (spin2 == 2) && (spin3 == 2)) return 3;
    if ((spin1  == 2) && (spin2 != 2) && (spin3 == 2)) return 3;
    
    // Three CHERRIES
    if ((spin1 == 2) && (spin2 == 2) && (spin3 == 2)) return 150;
    
    switch (spinValue) {
        case 000:
            winMultiplier = 100;	// 3 Bars
            break;
        case 888:
            winMultiplier = 100;	// 3 sevens
            break;
        case 111:
        case 222:
        case 333:
        case 444:
        case 555:
        case 666:
        case 777:
            winMultiplier = 3;		// 3 anything else --> 3X bet
            break;
            
        default:
            winMultiplier = 0;		// anything else --> lose
            break;
    }
    return	winMultiplier;
}

// Pop up an Alert to let user reset the game
-(void) youLost
{
    UIAlertController   *alert = [UIAlertController     alertControllerWithTitle:@"You Lose" message:@"Lost it all huh? Way to go champ!" preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:alert animated:YES completion:nil];
}




// LIGHT ANIMATIONS
-(void)setupGreenLightSequence
{
    UIImage* img1;
    UIImage* img2;
    UIImage* img3;
    UIImage* img4;
    UIImage* img5;
    
    greenLightSequenceImageView = [[UIImageView alloc] init];
    if (iphoneType == kiPhone6Plus) {
        img1 = [UIImage imageNamed:@"100greenTop6P.png"];
        img2 = [UIImage imageNamed:@"110greenTop6P.png"];
        img3 = [UIImage imageNamed:@"111greenTop6P.png"];
        img4 = [UIImage imageNamed:@"011greenTop6P.png"];
    } else { //smaller screen size
        img1 = [UIImage imageNamed:@"100greenTop.png"];
        img2 = [UIImage imageNamed:@"110greenTop.png"];
        img3 = [UIImage imageNamed:@"111greenTop.png"];
        img4 = [UIImage imageNamed:@"011greenTop.png"];
        
    }
    NSArray *images = [NSArray arrayWithObjects:img1, img2,img3,img4,img5, nil];
    
    [greenLightSequenceImageView setAnimationImages:images];
    [greenLightSequenceImageView setAnimationRepeatCount:0];
    [greenLightSequenceImageView setAnimationDuration:0.5];
    
    switch (iphoneType) {
        case kiPhone4S:
            greenLightSequenceImageView.frame = CGRectMake(71,1, 200, 20);
            break;
        case kiPhone5:
            greenLightSequenceImageView.frame = CGRectMake(71,1, 200, 20);
            break;
        case kiPhone6:
            greenLightSequenceImageView.frame = CGRectMake(100,1, 200, 20);
            break;
        case kiPhone6Plus:
            greenLightSequenceImageView.frame = CGRectMake(114,1, 200, 20);
            break;
            
        default:
            break;
    }
    
}

-(void)startGreenLightAnimation
{
    [greenLightSequenceImageView startAnimating];
    [self.view addSubview:greenLightSequenceImageView];
}
-(void)stopGreenLightAnimation
{
    [greenLightSequenceImageView stopAnimating];
    [greenLightSequenceImageView	removeFromSuperview];
}
-(void)setupRedLightSequence
{
    UIImage* img1;
    UIImage* img2;
    UIImage* img3;
    UIImage* img4;
    UIImage* img5;
    
    redLightSequenceImageView = [[UIImageView alloc] init];
    if (iphoneType == kiPhone6Plus) {
        img1 = [UIImage imageNamed:@"001redBottom6P.png"];
        img2 = [UIImage imageNamed:@"011redBottom6P.png"];
        img3 = [UIImage imageNamed:@"111redBottom6P.png"];
        img4 = [UIImage imageNamed:@"110redBottom6P.png"];
        img5 = [UIImage imageNamed:@"100redBottom6P.png"];
    } else { //smaller screen size
        img1 = [UIImage imageNamed:@"001redBottom.png"];
        img2 = [UIImage imageNamed:@"011redBottom.png"];
        img3 = [UIImage imageNamed:@"111redBottom.png"];
        img4 = [UIImage imageNamed:@"110redBottom.png"];
        img5 = [UIImage imageNamed:@"100redBottom.png"];
        
    }
    NSArray *images = [NSArray arrayWithObjects:img1, img2,img3,img4,img5, nil];
    
    [redLightSequenceImageView setAnimationImages:images];
    [redLightSequenceImageView setAnimationRepeatCount:0];
    [redLightSequenceImageView setAnimationDuration:0.5];
    switch (iphoneType) {
        case kiPhone4S:
            redLightSequenceImageView.frame = CGRectMake(71,5, 200, 15);
            break;
        case kiPhone5:
            redLightSequenceImageView.frame = CGRectMake(71,5, 200, 15);
            break;
        case kiPhone6:
            redLightSequenceImageView.frame = CGRectMake(100,5, 200, 15);
            break;
        case kiPhone6Plus:
            redLightSequenceImageView.frame = CGRectMake(114,5, 200, 15);
            break;
            
        default:
            break;
    }
}

-(void)startRedLightAnimation
{
    NSLog(@"Start Animating RED");
    [redLightSequenceImageView startAnimating];
    [self.view addSubview:redLightSequenceImageView];
}
-(void)stopRedLightAnimation
{
    [redLightSequenceImageView stopAnimating];
    [redLightSequenceImageView	removeFromSuperview];
}


// SOUND ANIMATIONS
-(void)makeButtonClick
{
    AudioServicesPlaySystemSound (self.clickSoundObject);
}

// PERSISTANCE - this saves the player's game state
// because we greatly simplified this game for newer versions of
// iOS, we don't actually do that much here. We're more concerned
// in this exercise about the process of converting...so while we
// do care about game state items such as score and last spin, we
// are not concerned about switch settings for whether to play sounds
// or not.
//
-(void)saveGameState
{
    NSLog(@"Calling Save Game State");
    NSMutableArray *userData = [[NSMutableArray	alloc] init];
    [userData	addObject:[NSNumber numberWithInt:(int)spin1]];
    [userData	addObject:[NSNumber numberWithInt:(int)spin2]];
    [userData	addObject:[NSNumber numberWithInt:(int)spin3]];
    [userData	addObject:[NSNumber	numberWithInt:self.winThisSpin]];
    [userData	addObject:[NSNumber	numberWithInt:self.thisBet]];
    [userData	addObject:[NSNumber	numberWithInt:self.totalCredits]];
    
    [[NSUserDefaults	standardUserDefaults] setObject: userData forKey:@"gameState"];
    [[NSUserDefaults	standardUserDefaults] synchronize];
}

-(void)restoreUserSettings
{
    
    NSLog(@"Called restore user settings");
    // CHECK USER SETTINGS
    
}



@end
