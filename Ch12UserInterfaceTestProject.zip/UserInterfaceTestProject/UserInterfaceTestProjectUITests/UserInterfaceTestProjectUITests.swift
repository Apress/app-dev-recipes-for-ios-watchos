//
//  UserInterfaceTestProjectUITests.swift
//  UserInterfaceTestProjectUITests
//
//  Created by Molly Maskrey on 4/2/16.
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import XCTest

class UserInterfaceTestProjectUITests: XCTestCase {

    let app = XCUIApplication()
    
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
//    func testMain() {
////        // Use recording to get started writing UI tests.
////        // Use XCTAssert and related functions to verify your tests produce the correct results.
////        
//        XCTAssert(app.navigationBars.staticTexts["Main View"].exists)
//        
//        // Test SecondaryView1 View Controller
//        app.buttons["Secondary View 1"].tap()
//        XCTAssert(app.navigationBars.staticTexts["Secondary View 1"].exists)
//        XCTAssert(app.staticTexts["Secondary View 1"].exists)
//        app.buttons["Display Text"].tap()
//        XCTAssert(app.staticTexts["ALPHA"].exists)
//        app.navigationBars.buttons["Back"].tap()
//        
//        // Test SecondaryView2 View Controller
//        app.buttons["Secondary View 2"].tap()
//        XCTAssert(app.navigationBars.staticTexts["Secondary View 2"].exists)
//        XCTAssert(app.staticTexts["Secondary View 2"].exists)
//        app.buttons["Display Text"].tap()
//        XCTAssert(app.staticTexts["ALPHA"].exists)
//        app.navigationBars.buttons["Back"].tap()
//    }
    
    func testRecording() {
        
        let app = XCUIApplication()
        
        XCTAssert(app.navigationBars.staticTexts["Main View"].exists)
        app.buttons["Secondary View 1"].tap()
        XCTAssert(app.navigationBars.staticTexts["Secondary View 1"].exists)
        XCTAssert(app.staticTexts["Secondary View 1"].exists)
        
        let displayTextButton = app.buttons["Display Text"]
        displayTextButton.tap()
        XCTAssert(app.staticTexts["ALPHA"].exists)
        
        app.navigationBars["Secondary View 1"].buttons["Main View"].tap()
        app.buttons["Secondary View 2"].tap()
        XCTAssert(app.navigationBars.staticTexts["Secondary View 2"].exists)
        XCTAssert(app.staticTexts["Secondary View 2"].exists)
        
        displayTextButton.tap()
        XCTAssert(app.staticTexts["BETA"].exists)
        app.navigationBars["Secondary View 2"].buttons["Main View"].tap()
        
    }
    
}
