//
//  ViewController.swift
//  UserInterfaceTestProject
//
//  Created by Molly Maskrey on 4/2/16.
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.title = "Main View"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

