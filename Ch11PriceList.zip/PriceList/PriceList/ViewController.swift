//
//  ViewController.swift
//  PriceList
//
//  Created by Molly Maskrey on 4/5/16.
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import UIKit

class ViewController: UIViewController , NSXMLParserDelegate{

@IBOutlet weak var outputLabel: UILabel!

var parser = NSXMLParser()
var element = NSString()
var elementType = NSString()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Create our parser
        parser = NSXMLParser(contentsOfURL:(NSURL(string:"http://176.32.230.252/mollymaskrey.com/book/pricelist.xml"))!)!
        parser.delegate = self
        parser.parse()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
    
        elementType = elementName
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String) {
    
        if (elementType.isEqualToString("title")) {
            print(string, terminator: " ")
            element = "\(element) \(string)"
            outputLabel.text = element as String
        }
    }

    func parserDidStartDocument(parser: NSXMLParser) {
        print("Started Parsing Document", terminator: " ")
    }

    func parserDidEndDocument(parser: NSXMLParser) {
        print("Finished Parsing Document", terminator: " ")
    }


}

