//
//  InterfaceController.swift
//  Sensor Interface WatchKit Extension
//
//  Created by Molly Maskrey on 8/30/15.
//  Copyright (c) 2015 Global Tek Labs. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController, WCSessionDelegate {

@IBOutlet weak var linkStatusLabel: WKInterfaceLabel!
    // Session Identifier
    var session : WCSession?
    
    
    
    // WK Connectivity
    func openSession () -> () {
        if(WCSession.isSupported()) {
            session = WCSession.defaultSession()
            session?.delegate = self
            session?.activateSession()
            print("watch: WC Session is SUPPORTED")
        } else {
            print("watch: WC Session is NOT SUPPORTED")
        }
    }


// Interval Timer
var intervalTimer = NSTimer()

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
    
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        // Let's set up a timer
        let interval:NSTimeInterval = 0.1
        if intervalTimer.valid{intervalTimer.invalidate()}
        intervalTimer = NSTimer.scheduledTimerWithTimeInterval(interval, target: self, selector: "checkSensorStatus", userInfo: nil, repeats: true)
    }
    
    
    // WatchKit Connectivity Delegate Methods
    
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject]) {
        if let status = message["CONNECT"] as? Bool {
            if (status == true) {
                linkStatusLabel.setText("connected")
                linkStatusLabel.setTextColor(UIColor .greenColor())
            } else {
                linkStatusLabel.setText("not connected")
                linkStatusLabel.setTextColor(UIColor .redColor())
            }
        }
    }
    
    //
    // This is our custom function that gets called whenever the timer fires
    // We check the sensorStatus and set the label as appropriate
    //
    func checkSensorStatus () -> () {
        // Get Data from phone using Watch Connectivity
        
        // First always try and open session if not already opened
        if let session = session where session.reachable {
            print("watch:WCSession with Watch is REACHABLE")
        } else {
            openSession()
        }
    }
    
    


    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
        intervalTimer.invalidate()
    }

}
