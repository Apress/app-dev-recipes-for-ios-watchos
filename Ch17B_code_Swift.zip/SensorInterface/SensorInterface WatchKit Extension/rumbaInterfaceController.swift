//
//  rumbaInterfaceController.swift
//  Sensor Interface
//
//  Created by Molly Maskrey on 8/30/15.
//  Copyright (c) 2015 Global Tek Labs. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class rumbaInterfaceController: WKInterfaceController, WCSessionDelegate {

    @IBOutlet weak var leadStatusLabel: WKInterfaceLabel!
    // Session Identifier
    var session : WCSession?
    
    // WK Connectivity
    func openSession () -> () {
        if(WCSession.isSupported()) {
            session = WCSession.defaultSession()
            session?.delegate = self
            session?.activateSession()
            print("watch: WC Session is SUPPORTED")
        } else {
            print("watch: WC Session is NOT SUPPORTED")
        }
    }

    
    // Interval Timer
    var intervalTimer = NSTimer()

    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        
        // Configure interface objects here.
        print("Rumba - awakeWithContext")
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        // Let's set up a timer
        let interval:NSTimeInterval = 0.1
        if intervalTimer.valid{intervalTimer.invalidate()}
        intervalTimer = NSTimer.scheduledTimerWithTimeInterval(interval, target: self, selector: "checkForToeLead", userInfo: nil, repeats: true)
    }
    
    // WatchKit Connectivity Delegate Methods
    
    func session(session: WCSession, didReceiveMessage message: [String : AnyObject]) {
        if let status = message["LEAD_TYPE"] as? Bool {
            if (status == true) {
                leadStatusLabel.setText("TOE LEAD")
                leadStatusLabel.setTextColor(UIColor .greenColor())
            } else {
                leadStatusLabel.setText("HEEL LEAD")
                leadStatusLabel.setTextColor(UIColor .redColor())
                // If we are doing the move incorrectly
                WKInterfaceDevice.currentDevice().playHaptic(.Failure)
            }
        }
    }
    
    
    //
    // This is our custom function that gets called whenever the timer fires
    // All we're gonna do is check and see if the session is open or not, and if not open one
    //
    func checkForToeLead () -> () {
        // Get Data from phone using Watch Connectivity
        
        // First always try and open session if not already opened
        if let session = session where session.reachable {
            print("watch:WCSession with Watch is REACHABLE")
        } else {
            openSession()
        }
    }



    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
        intervalTimer.invalidate()

    }

}
