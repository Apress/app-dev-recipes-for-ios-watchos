//
//  ViewController.swift
//  Sensor Interface
//
//  Created by Molly Maskrey on 8/14/15.
//  Copyright (c) 2015 Global Tek Labs. All rights reserved.
//

import UIKit
import CoreBluetooth
import WatchConnectivity


// Services
let GAP_SERVICE = "1800"
let DEV_INFO_SERVICE = "180a"
let DEVBD_SERVICE = "53239E8E-4EC5-4869-8773-52018C93CA3D"
let SENSOR_DATA_SERVICE =   "6D480F49-91D3-4A18-BE29-0D27F4109C23"


//
// Characteristics - we only care about two for this demo
//
let ROLL_CHARACTERISTIC = "35c93ef0-5517-440a-ad32-222a596eafc1"
let PITCH_CHARACTERISTIC = "192773e5-b433-4dfe-93ae-17b713172145"

// Helper Extension to Float type
extension Float {
    var degreesToRadians : CGFloat {
         return CGFloat(self) * CGFloat(M_PI) / 180.0
    }
}

//
// The CBCentralManagerDelegate protocol allows us to find Bluetooth Peripherals to connect with
//
// The CBPeripheralDelegate protocol allows us to locate services and characteristics of BTLE Peripherals
//
// And...add delegate for Watch Connectivity Framework
//
class ViewController: UIViewController, CBCentralManagerDelegate,CBPeripheralDelegate, WCSessionDelegate {

    @IBOutlet weak var statusLabel: UILabel!
    
    // Session Object for using Watch Connectivity
    var session :WCSession?
    
    var pitchValue : Float = 0
    var pitchBias : Float = 0
    var rollValue : Float = 0
    var rollBias : Float = 0
    
    
    // WKSession convenience functions
    func openSession () -> () {
        if(WCSession.isSupported()) {
            session = WCSession.defaultSession()
            session?.delegate = self
            session?.activateSession()
            print("WC Session is SUPPORTED")
        } else {
            print("WC Session is NOT SUPPORTED")
        }
    }
    
    func sendConnectionStatus (status:Bool) -> (){
        if let session = session where session.reachable {
            print("WCSession with Watch is REACHABLE")
            session.sendMessage(["CONNECT":status], replyHandler: nil, errorHandler: { (error ) -> Void in
                print("Error in sendConnectionStatus: \(error)")
            })
        } else {
            print("WCSession with Watch is NOT REACHABLE")
        }
    }
    
    func sendLeadType (leadType:Bool) -> (){
        if let session = session where session.reachable {
            print("WCSession with Watch is REACHABLE")
            session.sendMessage(["LEAD_TYPE":leadType], replyHandler: nil, errorHandler: { (error ) -> Void in
                print("Error in sendLeadType: \(error)")
            })
        } else {
            print("WCSession with Watch is NOT REACHABLE")
        }
    }
    
    @IBAction func calibrateSensor(sender: AnyObject) {
        pitchBias = -pitchValue
        rollBias = rollValue
        print("roll bias = \(rollBias); pitch bias = \(pitchBias)")

    }
    
    @IBAction func zeroBias(sender: AnyObject) {
        pitchBias = 0
        rollBias = 0
        
        print("Ext: Setting sensorStatus = false")

    }
    
    @IBOutlet weak var pitchView: UIImageView!
    @IBOutlet weak var rollView: UIImageView!
    
    var manager:CBCentralManager!
    var sensor:CBPeripheral!                // our MovementTek sensor
    var peripheralArray : [CBPeripheral] = []




    var xMotionAverage : Float = 0
    var yMotionAverage : Float = 0
    var xAveragingFactor : Float = 0.9
    var yAveragingFactor : Float = 0.9
    
    var managerState : Bool = false
    
    
//***********************************************************
//***************  THE BORING STUFF     *********************
//***********************************************************
    
    override func viewDidLoad() {
        super.viewDidLoad()
    // create a Core Bluetooth central manager (client) object with ourselves as the delegate
//*******************INTERESTING*****************************
    manager = CBCentralManager(delegate: self, queue: dispatch_get_main_queue())

    // Open Session With Watch
    openSession()
        
    // Assume we're not connected at start
    sendConnectionStatus(false)

//***********************************************************
    // Set up Labels
    statusLabel.text = "NOT CONNECTED"
    statusLabel.textColor = UIColor.redColor()
    }
    
    override func viewDidAppear(animated: Bool) {
    // debug
        print("VIEW DID APPEAR")
        
    // Pass data to Watch through WATCH CONNECTIVITY
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//***********************************************************
//***************  THE INTERESTING STUFF   ******************
//***********************************************************
    

    // CORE BLUETOOTH CENTRAL MANAGER DELEGATE METHODS
    
    // THIS METHOD IS REQUIRED to find any Bluetooth devices
    // First make sure BT is available and turned on
    // Then, start scanning for BT peripherals
    func centralManagerDidUpdateState(central: CBCentralManager) {
        // see if our BT is powered on first
        if central.state == CBCentralManagerState.PoweredOn  {
            print("Bluetooth is on, scanning for peripherals")
            manager.scanForPeripheralsWithServices(nil, options: nil)
        }
    }
    
    //
    // DISCOVERED A PERIPHERAL
    // A Bluetooth device is within range, try connecting to it
    //
    func centralManager(central: CBCentralManager, didDiscoverPeripheral peripheral: CBPeripheral, advertisementData: [String : AnyObject], RSSI: NSNumber) {

          if let _ = peripheral.name {
            if peripheral.name == "iThotics Sensor" {
                // set our sensor in case we need it later
                sensor = peripheral
                print("Found \(peripheral.name), stop scanning and connect it")
                manager.connectPeripheral(peripheral, options: nil)
                manager.stopScan()
            }
          }
     }

    //
    // CONNECTED PERIPHERAL
    // We connected to the Bluetooth device, let's see what services it has
    //
    func centralManager(central: CBCentralManager, didConnectPeripheral peripheral: CBPeripheral) {
        //
        print("Connected to the MovementTek Sensor")
        statusLabel.text = "CONNECTED"
        statusLabel.textColor = UIColor.greenColor()
        // Let the Watch know we're connected
        sendConnectionStatus(true)
        peripheral.delegate = self
        peripheral.discoverServices(nil)
    }
    
    //
    // DIS-CONNECTED PERIPHERAL
    // The peripheral disconnected, let' try re-connecting
    //
    func centralManager(central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: NSError?) {
    //
        print("Disconnected from the MovementTek Sensor - let's try reconnecting")
        statusLabel.text = "NOT CONNECTED"
        statusLabel.textColor = UIColor.redColor()
        
        // Let the Watch know we're disconnected
        sendConnectionStatus(false)

        // try to reconnect
        manager.connectPeripheral(peripheral, options: nil)
        
        // reset graphics
        rollView.transform = CGAffineTransformMakeRotation(0)
        pitchView.transform = CGAffineTransformMakeRotation(0)
    }
    
    //
    // FAILED TO CONNECT TO PERIPHERAL
    // When, for some reason, we can't connect to the peripheral, this method is executed
    //
    func centralManager(central: CBCentralManager, didFailToConnectPeripheral peripheral: CBPeripheral, error: NSError?) {
        print("Error: Couldn't connect to a peripheral - let's try again")
        // try to reconnect
        manager.connectPeripheral(peripheral, options: nil)
    }


    //
    //  PERIPHERAL DELAGATE METHODS
    //
    //**********************************************************************************
    //
    //  SERVICES
    //
    
    func peripheral(peripheral: CBPeripheral, didDiscoverServices error: NSError?) {
    // 
        print("Did discover \(peripheral.services!.count) services for \(sensor.name)")
        for aService in peripheral.services! {
        
            print("Service = \(aService.UUID.description)")
            if aService.UUID.description.uppercaseString == DEVBD_SERVICE.uppercaseString {
                print("Go discover Characteristics for \(aService.UUID.description)")
                sensor.discoverCharacteristics(nil , forService: aService )
            }
            print("Looking for \(SENSOR_DATA_SERVICE.uppercaseString)")
            if aService.UUID.description.uppercaseString == SENSOR_DATA_SERVICE.uppercaseString  {
                print("Go discover Characteristics for Sensor Data")
                sensor.discoverCharacteristics(nil , forService: aService )
            }
        }
    }
    
    //
    //  CHARACTERISTICS
    //
    func peripheral(peripheral: CBPeripheral, didDiscoverCharacteristicsForService service: CBService, error: NSError?) {
    //
        for aCharacteristic in service.characteristics! {
            if aCharacteristic.UUID.description.uppercaseString == ROLL_CHARACTERISTIC.uppercaseString  {
                print("Found Foot Roll Characteristic")
                sensor.setNotifyValue(true, forCharacteristic: aCharacteristic )
            }
            if aCharacteristic.UUID.description.uppercaseString == PITCH_CHARACTERISTIC.uppercaseString  {
                print("Found Foot Pitch Characteristic")
                sensor.setNotifyValue(true, forCharacteristic: aCharacteristic  )
            }
        }
    }
    
    
    //
    // WHEN THE CHARACTERISTICS UPDATE (new data)
    // This is where we get the new data from the sensor and do something with it
    //
    func peripheral(peripheral: CBPeripheral, didUpdateValueForCharacteristic characteristic: CBCharacteristic, error: NSError?) {
    //
    // X AXIS === FOOT ROLL
    //
        if characteristic.UUID.description.uppercaseString == ROLL_CHARACTERISTIC.uppercaseString  {
        
            let dataBytes = characteristic.value
            let dataLength = dataBytes!.length
            var dataArray = [UInt8](count: dataLength, repeatedValue: 0)
            dataBytes!.getBytes(&dataArray, length: dataLength * sizeof(UInt8))
            var sensorValue : Int16 = Int16(dataArray[0]) << 8 + Int16(dataArray[1])
            sensorValue /= 4
            xMotionAverage = ( (xMotionAverage * xAveragingFactor) + Float(sensorValue) ) / 40
            xMotionAverage += rollBias
            
            rollValue = xMotionAverage
            rollView.transform = CGAffineTransformMakeRotation(xMotionAverage.degreesToRadians)
        }
    
    //
    // Y AXIS === FOOT PITCH
    //
        if characteristic.UUID.description.uppercaseString == PITCH_CHARACTERISTIC.uppercaseString  {
        
            let dataBytes = characteristic.value
            let dataLength = dataBytes!.length
            var dataArray = [UInt8](count: dataLength, repeatedValue: 0)
            dataBytes!.getBytes(&dataArray, length: dataLength * sizeof(UInt8))
            var sensorValue : Int16 = Int16(dataArray[0]) << 8 + Int16(dataArray[1])
            sensorValue /= 4
            yMotionAverage = ( (yMotionAverage * yAveragingFactor) + Float(sensorValue) ) / 20
            yMotionAverage += pitchBias
            
            pitchValue = yMotionAverage
            pitchView.transform = CGAffineTransformMakeRotation(-yMotionAverage.degreesToRadians)
            
            //
            // FOR FOOT PITCH, PASS THE DATA TO WATCH via WATCH CONNECTIVITY
            //
            if pitchValue >= 0 {
                sendLeadType(true)   // TOE LEAD
            } else {
                sendLeadType(false)  // HEEL LEAD
            }
        }
    }

}   // END of the viewController CLASS

