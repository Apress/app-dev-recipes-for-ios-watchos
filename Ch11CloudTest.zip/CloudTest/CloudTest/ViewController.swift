//
//  ViewController.swift
//  CloudTest
//
//  Created by Molly Maskrey on 4/6/16.
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import UIKit
import CloudKit

class ViewController: UIViewController {

    let container = CKContainer.defaultContainer()
    var record = CKRecord(recordType: "Inventory")
    let publicDB = CKContainer.defaultContainer().publicCloudDatabase
    
    let privateDB = CKContainer.defaultContainer().privateCloudDatabase     // to read, we'll us a private DB
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        addRecord()
        readPrivateRecord()

    }
    
    //
    // Read record from private database that we entered by using the iCloud Dashboard
    //
    func readPrivateRecord() {
    
        privateDB.fetchRecordWithID(CKRecordID(recordName: "ef0fe9e7-bb50-441e-a8f5-8efc257271e4"), completionHandler: {record, error in
            if error == nil {
                print(record)
            } else {
                print(error)
            }
         
          })
    }
    
    
    //
    //  Add records to our iCloud Database using the CloudKit framework
    func addRecord() {
        record.setValue("1001", forKey: "ItemNumber")
        record.setValue("iPhone 6 Case - Black", forKey: "ItemName")
        record.setValue(20, forKey: "ItemPrice")
        record.setValue(100, forKey: "ItemQuantity")
        
        publicDB.saveRecord(record) { (savedRecord, error) -> Void in
            if error == nil {
                print("record saved to iCloud database using CloudKit")
            } else {
            print(error)
            return
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

