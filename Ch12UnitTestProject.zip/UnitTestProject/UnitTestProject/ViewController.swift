//
//  ViewController.swift
//  UnitTestProject
//
//  Created by Molly Maskrey on 3/27/16.
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import UIKit

extension UIViewController {
    public func divideTwoNumbers (a:Int, b:Int) -> Int {
        return (a/b)
    }
}

public class MyViewController: UIViewController {

    override public func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
     override public func divideTwoNumbers(a: Int, b: Int) -> Int {
        return (a/b)
    }

}



