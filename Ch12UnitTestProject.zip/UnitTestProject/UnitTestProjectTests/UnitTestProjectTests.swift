//
//  UnitTestProjectTests.swift
//  UnitTestProjectTests
//
//  Copyright © 2016 Molly Maskrey. All rights reserved.
//

import XCTest
@testable import UnitTestProject


class UnitTestProjectTests: XCTestCase {

    var vc : MyViewController!       // #1 ADDED LINE
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        vc = MyViewController()     // #2 ADDED LINE
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testDivide() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        let c = vc.divideTwoNumbers(1,b: 1)         // #3 ADDED LINE
        
        XCTAssert(c == 1)
    }
    
}
